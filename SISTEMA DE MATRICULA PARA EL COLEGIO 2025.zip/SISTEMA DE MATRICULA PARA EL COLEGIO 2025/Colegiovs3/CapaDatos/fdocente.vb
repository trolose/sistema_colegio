﻿Imports System.Data.SqlClient
Imports System.Windows.Forms
Imports CapaEntidad
Public Class fdocente
    Inherits Conexion
    Dim cmd As New SqlCommand
    Private txtbuscar As Object

    Public Function mostrardocente() As DataTable
        Try
            Conectado()
            cmd = New SqlCommand("DOCENTESELECT")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx


            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            Desconectado()
        End Try
    End Function


    Public Function insertardocente(ByVal dts As vdocente) As String
        Try
            Conectado()
            cmd = New SqlCommand("DOCENTEINSERT")
            cmd.CommandType = CommandType.StoredProcedure


            cmd.Connection = bcx

            cmd.Parameters.AddWithValue("@dniDoc", dts.gdniDoc)
            cmd.Parameters.AddWithValue("@nomDoc", dts.gnomDoc)
            cmd.Parameters.AddWithValue("@apaDoc", dts.gapaDoc)
            cmd.Parameters.AddWithValue("@amaDoc", dts.gamaDoc)
            cmd.Parameters.AddWithValue("@edaDoc", dts.gedaDoc)
            cmd.Parameters.AddWithValue("@sexDoc", dts.gsexDoc)
            cmd.Parameters.AddWithValue("@telDoc", dts.gtelDoc)
            cmd.Parameters.AddWithValue("@dirDoc", dts.gdirDoc)
            cmd.Parameters.AddWithValue("@fnaDoc", dts.gfnaDoc)
            cmd.Parameters.AddWithValue("@emaDoc", dts.gemaDoc)
            cmd.Parameters.AddWithValue("@espDoc", dts.gespDoc)

            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show("Posibles datos duplicados o erroneos,verifique", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        Finally
            Desconectado()
        End Try
    End Function


    Public Function editardocente(ByVal dts As vdocente) As Boolean
        Try
            Conectado()
            cmd = New SqlCommand("DOCENTEUPDATE")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx

            cmd.Parameters.AddWithValue("@dniDoc", dts.gdniDoc)
            cmd.Parameters.AddWithValue("@nomDoc", dts.gnomDoc)
            cmd.Parameters.AddWithValue("@apaDoc", dts.gapaDoc)
            cmd.Parameters.AddWithValue("@amaDoc", dts.gamaDoc)
            cmd.Parameters.AddWithValue("@edaDoc", dts.gedaDoc)
            cmd.Parameters.AddWithValue("@sexDoc", dts.gsexDoc)
            cmd.Parameters.AddWithValue("@telDoc", dts.gtelDoc)
            cmd.Parameters.AddWithValue("@dirDoc", dts.gdirDoc)
            cmd.Parameters.AddWithValue("@fnaDoc", dts.gfnaDoc)
            cmd.Parameters.AddWithValue("@emaDoc", dts.gemaDoc)
            cmd.Parameters.AddWithValue("@espDoc", dts.gespDoc)
            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        Finally
            Desconectado()
        End Try
    End Function

    Public Function eliminardocente(ByVal dts As vdocente) As Boolean
        Try
            Conectado()
            cmd = New SqlCommand("DOCENTEDELETE")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx

            cmd.Parameters.Add("@dniDoc", SqlDbType.NVarChar, 50).Value = dts.gdniDoc
            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        End Try
    End Function

    Public Function buscardnidocente(ByVal dts As vdocente) As String
        Try
            Conectado()
            cmd = New SqlCommand("BUSCAR_DOCENTE")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx

            cmd.Parameters.AddWithValue("@dniDoc", txtbuscar.Text)


            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        Finally
            Desconectado()
        End Try

    End Function













End Class
