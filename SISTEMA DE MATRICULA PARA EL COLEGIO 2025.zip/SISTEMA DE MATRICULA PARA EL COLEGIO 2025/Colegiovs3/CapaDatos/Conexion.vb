﻿Imports System.Data.SqlClient
Public Class Conexion
    Dim coman As New SqlCommand
    Public Shared bcx As New SqlConnection
    Public Event Load(sender As Object, e As EventArgs)

    Protected Shared Function Conectado()
        Try
            bcx = New SqlConnection("Data Source = .; Initial Catalog = ColegioBD; Integrated Security=true")
            bcx.Open()
            Return True
        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        End Try
    End Function

    Public Shared Function Desconectado()
        Try
            If bcx.State = ConnectionState.Open Then
                bcx.Close()
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        End Try
    End Function
    Public Function validar(ByVal dat As CapaEntidad.ELogin) As Boolean
        Try
            Conectado()

            coman = New SqlCommand("Acceder")
            coman.CommandType = CommandType.StoredProcedure
            coman.Connection = bcx
            coman.Parameters.AddWithValue("@id", dat.usuario)
            coman.Parameters.AddWithValue("@contraseña", dat.pass)
            coman.Parameters.AddWithValue("@tipo", dat.tipousuario)
            Dim dr As SqlDataReader
            dr = coman.ExecuteReader
            If dr.HasRows = True Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        Finally
            Desconectado()
        End Try
    End Function
End Class

