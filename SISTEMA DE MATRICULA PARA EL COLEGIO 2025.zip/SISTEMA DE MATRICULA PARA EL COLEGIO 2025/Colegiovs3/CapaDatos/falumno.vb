﻿Imports System.Data.SqlClient
Imports System.Windows.Forms
Imports CapaEntidad

Public Class falumno
    Inherits Conexion
    Dim cmd As New SqlCommand
    Private txtbuscar As Object

    Public Function buscardnialumno(ByVal dts As valumno) As String
        Try
            Conectado()
            cmd = New SqlCommand("BUSCAR_DNI_ALUMNO")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx

            cmd.Parameters.AddWithValue("@dniAlu", txtbuscar.Text)


            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        Finally
            Desconectado()
        End Try

    End Function


    Public Function mostraralumno() As DataTable
        Try
            Conectado()
            cmd = New SqlCommand("AlumnoSELECT")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx


            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            Desconectado()
        End Try
    End Function




    Public Function insertaralumno(ByVal dts As valumno) As String
        Try
            Conectado()
            cmd = New SqlCommand("ALUMNOINSERT")
            cmd.CommandType = CommandType.StoredProcedure


            cmd.Connection = bcx

            cmd.Parameters.AddWithValue("@dniAlu", dts.gdniAlu)
            cmd.Parameters.AddWithValue("@nomAlu", dts.gnomAlu)
            cmd.Parameters.AddWithValue("@apaAlu", dts.gapaAlu)
            cmd.Parameters.AddWithValue("@amaAlu", dts.gamaAlu)
            cmd.Parameters.AddWithValue("@edaAlu", dts.gedaAlu)
            cmd.Parameters.AddWithValue("@sexAlu", dts.gsexAlu)
            cmd.Parameters.AddWithValue("@telAlu", dts.gtelAlu)
            cmd.Parameters.AddWithValue("@dirAlu", dts.gdirAlu)
            cmd.Parameters.AddWithValue("@fnaAlu", dts.gfnaAlu)
            cmd.Parameters.AddWithValue("@emaAlu", dts.gemaAlu)
            cmd.Parameters.AddWithValue("@estado", dts.gestado)
            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show("Posibles datos duplicados o erronoes,verifique", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        Finally
            Desconectado()
        End Try
    End Function



    Public Function editaralumno(ByVal dts As valumno) As Boolean
        Try
            Conectado()
            cmd = New SqlCommand("ALUMNOUPDATE")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx
            cmd.Parameters.AddWithValue("@dniAlu", dts.gdniAlu)
            cmd.Parameters.AddWithValue("@nomAlu", dts.gnomAlu)
            cmd.Parameters.AddWithValue("@apaAlu", dts.gapaAlu)
            cmd.Parameters.AddWithValue("@amaAlu", dts.gamaAlu)
            cmd.Parameters.AddWithValue("@edaAlu", dts.gedaAlu)
            cmd.Parameters.AddWithValue("@sexAlu", dts.gsexAlu)
            cmd.Parameters.AddWithValue("@telAlu", dts.gtelAlu)
            cmd.Parameters.AddWithValue("@dirAlu", dts.gdirAlu)
            cmd.Parameters.AddWithValue("@fnaAlu", dts.gfnaAlu)
            cmd.Parameters.AddWithValue("@emaAlu", dts.gemaAlu)
            cmd.Parameters.AddWithValue("@estado", dts.gestado)

            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        Finally
            Desconectado()
        End Try
    End Function
    Public Function eliminaralumno(ByVal dts As valumno) As Boolean
        Try
            Conectado()
            cmd = New SqlCommand("ALUMNODELETE")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx

            cmd.Parameters.Add("@dniAlu", SqlDbType.NVarChar, 50).Value = dts.gdniAlu
            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show("Ya cuenta con matricula registrada", "Imposible eliminar", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        End Try
    End Function



End Class