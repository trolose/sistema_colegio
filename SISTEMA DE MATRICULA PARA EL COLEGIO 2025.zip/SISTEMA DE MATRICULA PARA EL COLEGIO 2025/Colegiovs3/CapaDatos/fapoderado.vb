﻿Imports System.Data.SqlClient
Imports System.Windows.Forms
Imports CapaEntidad
Public Class fapoderado
    Inherits Conexion
    Dim cmd As New SqlCommand
    Private txtbuscar As Object


    Public Function buscardniapoderado(ByVal dts As vapoderado) As String
        Try
            Conectado()
            cmd = New SqlCommand("BUSCARDNIAPODERADO")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx

            cmd.Parameters.AddWithValue("@dniApo", txtbuscar.Text)


            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        Finally
            Desconectado()
        End Try

    End Function

    Public Function mostrarapoderado() As DataTable
        Try
            Conectado()
            cmd = New SqlCommand("APODERADOSELECT")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx


            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            Desconectado()
        End Try
    End Function

    Public Function insertarapoderado(ByVal dts As vapoderado) As String
        Try
            Conectado()
            cmd = New SqlCommand("APODERADOINSERT")
            cmd.CommandType = CommandType.StoredProcedure


            cmd.Connection = bcx

            cmd.Parameters.AddWithValue("@dniApo", dts.gdniApo)
            cmd.Parameters.AddWithValue("@nomApo", dts.gnomApo)
            cmd.Parameters.AddWithValue("@apaApo", dts.gapaApo)
            cmd.Parameters.AddWithValue("@amaApo", dts.gamaApo)
            cmd.Parameters.AddWithValue("@edaApo", dts.gedaApo)
            cmd.Parameters.AddWithValue("@sexApo", dts.gsexApo)
            cmd.Parameters.AddWithValue("@telApo", dts.gtelApo)
            cmd.Parameters.AddWithValue("@dirApo", dts.gdirApo)
            cmd.Parameters.AddWithValue("@fnaApo", dts.gfnaApo)
            cmd.Parameters.AddWithValue("@ocuApo", dts.gocuApo)
            cmd.Parameters.AddWithValue("@eciApo", dts.geciApo)
            cmd.Parameters.AddWithValue("@ginApo", dts.gginApo)

            If cmd.ExecuteNonQuery Then


                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show("Posibles datos duplicados o inexistentes,verifique", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        Finally
            Desconectado()
        End Try
    End Function

    Private Function MENSAJE() As String
        Throw New NotImplementedException()
    End Function

    Public Function editarapoderado(ByVal dts As vapoderado) As Boolean
        Try
            Conectado()
            cmd = New SqlCommand("APODERADOUPDATE")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx

            cmd.Parameters.AddWithValue("@dniApo", dts.gdniApo)
            cmd.Parameters.AddWithValue("@nomApo", dts.gnomApo)
            cmd.Parameters.AddWithValue("@apaApo", dts.gapaApo)
            cmd.Parameters.AddWithValue("@amaApo", dts.gamaApo)
            cmd.Parameters.AddWithValue("@edaApo", dts.gedaApo)
            cmd.Parameters.AddWithValue("@sexApo", dts.gsexApo)
            cmd.Parameters.AddWithValue("@telApo", dts.gtelApo)
            cmd.Parameters.AddWithValue("@dirApo", dts.gdirApo)
            cmd.Parameters.AddWithValue("@fnaApo", dts.gfnaApo)
            cmd.Parameters.AddWithValue("@ocuApo", dts.gocuApo)
            cmd.Parameters.AddWithValue("@eciApo", dts.geciApo)
            cmd.Parameters.AddWithValue("@ginApo", dts.gginApo)

            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        Finally
            Desconectado()
        End Try
    End Function

    Public Function eliminarapoderado(ByVal dts As vapoderado) As Boolean
        Try
            Conectado()
            cmd = New SqlCommand("APODERADODELETE")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx

            cmd.Parameters.Add("@dniApo", SqlDbType.NVarChar, 50).Value = dts.gdniApo
            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show("Ya cuenta con un parentesco definido", "Imposible eliminar", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        End Try
    End Function
End Class
