﻿Imports System.Data.SqlClient
Imports CapaEntidad
Public Class faula
    Inherits Conexion
    Dim cmd As New SqlCommand

    Public Function mostraraula() As DataTable
        Try
            Conectado()
            cmd = New SqlCommand("AULASELECT")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx


            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            Desconectado()
        End Try
    End Function

    Public Function insertaraula(ByVal dts As vaula) As String
        Try
            Conectado()
            cmd = New SqlCommand("AULAINSERT")
            cmd.CommandType = CommandType.StoredProcedure


            cmd.Connection = bcx

            cmd.Parameters.AddWithValue("@codAul", dts.gcodAul)
            cmd.Parameters.AddWithValue("@capAul", dts.gcapAul)
            cmd.Parameters.AddWithValue("@vliAul", dts.gvliAul)


            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        Finally
            Desconectado()
        End Try
    End Function

    Public Function editarnota(ByVal dts As vaula) As Boolean
        Try
            Conectado()
            cmd = New SqlCommand("AULAUPDATE")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx

            cmd.Parameters.AddWithValue("@codAul", dts.gcodAul)
            cmd.Parameters.AddWithValue("@capAul", dts.gcapAul)
            cmd.Parameters.AddWithValue("@vliAul", dts.gvliAul)


            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        Finally
            Desconectado()
        End Try
    End Function

    Public Function eliminaraula(ByVal dts As vaula) As Boolean
        Try
            Conectado()
            cmd = New SqlCommand("AULADELETE")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx

            cmd.Parameters.Add("@codAul", SqlDbType.NVarChar, 50).Value = dts.gcodAul
            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        End Try
    End Function
End Class
