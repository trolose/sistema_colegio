﻿Imports System.Data.SqlClient
Imports System.Windows.Forms
Imports CapaEntidad
Public Class fparentesco
    Inherits Conexion
    Dim cmd As New SqlCommand

    Public Function eliminarparentesco(ByVal dts As vparentesco) As Boolean
        Try
            Conectado()
            cmd = New SqlCommand("PARENTESCODELETE")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx

            cmd.Parameters.Add("@codPar", SqlDbType.NVarChar, 50).Value = dts.gcodPar
            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        End Try
    End Function

    Public Function insertarparentesco(ByVal dts As vparentesco) As String
        Try
            Conectado()
            cmd = New SqlCommand("PARENTESCOINSERT")
            cmd.CommandType = CommandType.StoredProcedure


            cmd.Connection = bcx
            'cmd.Parameters.AddWithValue("@codPar", dts.gcodPar)
            cmd.Parameters.AddWithValue("@parPar", dts.gparPar)
            cmd.Parameters.AddWithValue("@dniAlu", dts.gdniAlu)
            cmd.Parameters.AddWithValue("@dniApo", dts.gdniApo)


            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show("Posibles datos duplicados o inexistentes,verifique", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
            Return False
        Finally
            Desconectado()
        End Try
    End Function

    Public Function mostrarparentesco() As DataTable
        Try
            Conectado()
            cmd = New SqlCommand("PARENTESCOSELECT")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx


            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            Desconectado()
        End Try
    End Function



End Class
