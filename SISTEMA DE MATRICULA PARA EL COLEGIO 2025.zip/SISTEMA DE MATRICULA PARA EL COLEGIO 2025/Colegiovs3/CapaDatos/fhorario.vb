﻿Imports System.Data.SqlClient
Imports System.Windows.Forms
Imports CapaEntidad

Public Class fhorario
    Inherits Conexion
    Dim cmd As New SqlCommand
    Private txtbuscar As Object

    Public Function buscarhorario(ByVal dts As vhorario) As String
        Try
            Conectado()
            cmd = New SqlCommand("BUSCAR_HORARIO")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx

            cmd.Parameters.AddWithValue("@dniDoc", txtbuscar.Text)


            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        Finally
            Desconectado()
        End Try

    End Function

    Public Function mostrarhorario() As DataTable
        Try
            Conectado()
            cmd = New SqlCommand("SELECTHORARIO")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx


            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            Desconectado()
        End Try
    End Function

    Public Function insertarhorario(ByVal dts As vhorario) As String
        Try
            Conectado()
            cmd = New SqlCommand("INSERTHORARIO")
            cmd.CommandType = CommandType.StoredProcedure


            cmd.Connection = bcx

            cmd.Parameters.AddWithValue("@codHor", dts.gcodHor)
            cmd.Parameters.AddWithValue("@diaHor", dts.gdiaHor)
            cmd.Parameters.AddWithValue("@hinHor", dts.ghinHor)
            cmd.Parameters.AddWithValue("@HfiHor", dts.gHfiHor)
            cmd.Parameters.AddWithValue("@secHor", dts.gsecHor)
            cmd.Parameters.AddWithValue("@codAul", dts.gcodAul)
            cmd.Parameters.AddWithValue("@dniDoc", dts.gdniDoc)
            cmd.Parameters.AddWithValue("@codCur", dts.gcodCur)

            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show("Posibles datos duplicados o inexistentes,verifique", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        Finally
            Desconectado()
        End Try
    End Function

    Public Function editarhorario(ByVal dts As vhorario) As Boolean
        Try
            Conectado()
            cmd = New SqlCommand("UPDATEHORARIO")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx

            cmd.Parameters.AddWithValue("codHor", dts.gcodHor)
            cmd.Parameters.AddWithValue("@diaHor", dts.gdiaHor)
            cmd.Parameters.AddWithValue("@hinHor", dts.ghinHor)
            cmd.Parameters.AddWithValue("@HfiHor", dts.gHfiHor)
            cmd.Parameters.AddWithValue("@secHor", dts.gsecHor)
            cmd.Parameters.AddWithValue("@codAul", dts.gcodAul)
            cmd.Parameters.AddWithValue("@dniDoc", dts.gdniDoc)
            cmd.Parameters.AddWithValue("@codCur", dts.gcodCur)

            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        Finally
            Desconectado()
        End Try
    End Function
    Public Function eliminarhorario(ByVal dts As vhorario) As Boolean
        Try
            Conectado()
            cmd = New SqlCommand("HORARIODELETE")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx

            cmd.Parameters.Add("@dniDoc", SqlDbType.NVarChar, 50).Value = dts.gcodHor
            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        End Try
    End Function


End Class
