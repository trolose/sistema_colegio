﻿Imports System.Data.SqlClient
Imports System.Windows.Forms
Imports CapaEntidad
Public Class fmatricula
    Inherits Conexion
    Dim cmd As New SqlCommand

    Public Function mostrarmatricula() As DataTable
        Try

            Conectado()
            cmd = New SqlCommand("MATRICULASELECT")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx

            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            Desconectado()
        End Try
    End Function
    Public Function insertarmatricula(ByVal dts As vmatricula) As Boolean
        Try
            Conectado()
            cmd = New SqlCommand("MATRICULAINSERT")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx

            cmd.Parameters.AddWithValue("@codMat", dts.gcodMat)
            cmd.Parameters.AddWithValue("@fecMat", dts.gfecMat)
            cmd.Parameters.AddWithValue("@monMat", dts.gmonMat)
            cmd.Parameters.AddWithValue("@graMat", dts.ggraMat)
            cmd.Parameters.AddWithValue("@secMat", dts.gsecMat)
            cmd.Parameters.AddWithValue("@codAul", dts.gcodAul)
            cmd.Parameters.AddWithValue("@dniAlu", dts.gdniAlu)
            cmd.Parameters.AddWithValue("@numAes", dts.gnumAes)


            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show("Posibles datos duplicados o inexistentes,verifique", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        Finally
            Desconectado()
        End Try
    End Function
    Public Function actualizarmatricula(ByVal dts As vmatricula) As Boolean
        Try
            Conectado()
            cmd = New SqlCommand("MATRICULAUPDATE1")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx

            cmd.Parameters.AddWithValue("@codMat", dts.gcodMat)
            cmd.Parameters.AddWithValue("@fecMat", dts.gfecMat)
            cmd.Parameters.AddWithValue("@monMat", dts.gmonMat)
            cmd.Parameters.AddWithValue("@graMat", dts.ggraMat)
            cmd.Parameters.AddWithValue("@secMat", dts.gsecMat)
            cmd.Parameters.AddWithValue("@codAul", dts.gcodAul)
            cmd.Parameters.AddWithValue("@dniAlu", dts.gdniAlu)
            cmd.Parameters.AddWithValue("@numAes", dts.gnumAes)

            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        Finally
            Desconectado()
        End Try
    End Function

    Public Function eliminarmatricula(ByVal dts As vmatricula) As Boolean
        Try
            Conectado()
            cmd = New SqlCommand("MATRICULADELETE")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx

            cmd.Parameters.Add("@codMat", SqlDbType.NVarChar, 50).Value = dts.gcodMat
            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show("Ya cuenta con un alumno registrado", "Imposible eliminar", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        End Try
    End Function
End Class

