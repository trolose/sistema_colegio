﻿Imports System.Data.SqlClient
Imports System.Windows.Forms
Imports CapaEntidad

Public Class fañoescolar

    Inherits Conexion
    Dim cmd As New SqlCommand


    Public Function mostrarañoescolar() As DataTable
        Try
            Conectado()
            cmd = New SqlCommand("AÑOSELECT")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx


            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            Desconectado()
        End Try
    End Function
    Public Function insertaraño(ByVal dts As vañoescolar) As String
        Try
            Conectado()
            cmd = New SqlCommand("AÑOINSERT")
            cmd.CommandType = CommandType.StoredProcedure


            cmd.Connection = bcx

            cmd.Parameters.AddWithValue("@numAes", dts.gnumAes)
            cmd.Parameters.AddWithValue("@finiAes", dts.gfiniAes)
            cmd.Parameters.AddWithValue("@fteAes", dts.gfteAes)


            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        Finally
            Desconectado()
        End Try
    End Function

    Public Function editaraño(ByVal dts As vañoescolar) As Boolean
        Try
            Conectado()
            cmd = New SqlCommand("AÑOUPDATE")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx

            cmd.Parameters.AddWithValue("@numAes", dts.gnumAes)
            cmd.Parameters.AddWithValue("@finiAes", dts.gfiniAes)
            cmd.Parameters.AddWithValue("@fteAes", dts.gfteAes)


            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        Finally
            Desconectado()
        End Try
    End Function

    Public Function eliminaraño(ByVal dts As vañoescolar) As Boolean
        Try
            Conectado()
            cmd = New SqlCommand("AÑODELETE")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = bcx

            cmd.Parameters.Add("@numAes", SqlDbType.NVarChar, 50).Value = dts.gnumAes
            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show("Ya cuenta con año escolar registrada", "Imposible eliminar", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        End Try
    End Function
End Class
