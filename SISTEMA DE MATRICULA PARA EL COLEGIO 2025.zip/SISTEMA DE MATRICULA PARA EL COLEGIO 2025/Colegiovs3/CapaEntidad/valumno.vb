﻿Public Class valumno
    Dim dniAlu, nomAlu, apaAlu, amaAlu, sexAlu, dirAlu, fnaAlu, emaAlu, estado As String
    Dim edaAlu, telAlu As Integer

    Public Property gdniAlu
        Get
            Return dniAlu

        End Get
        Set(ByVal value)
            dniAlu = value
        End Set
    End Property

    Public Property gnomAlu
        Get
            Return nomAlu
        End Get
        Set(ByVal value)
            nomAlu = value
        End Set
    End Property

    Public Property gapaAlu
        Get
            Return apaAlu
        End Get
        Set(ByVal value)
            apaAlu = value
        End Set
    End Property

    Public Property gamaAlu
        Get
            Return amaAlu
        End Get
        Set(ByVal value)
            amaAlu = value
        End Set
    End Property

    Public Property gedaAlu
        Get
            Return edaAlu
        End Get
        Set(ByVal value)
            edaAlu = value
        End Set
    End Property

    Public Property gsexAlu
        Get
            Return sexAlu
        End Get
        Set(ByVal value)
            sexAlu = value
        End Set
    End Property

    Public Property gtelAlu
        Get
            Return telAlu
        End Get
        Set(ByVal value)
            telAlu = value

        End Set
    End Property

    Public Property gdirAlu
        Get
            Return dirAlu
        End Get
        Set(ByVal value)
            dirAlu = value
        End Set
    End Property

    Public Property gfnaAlu
        Get
            Return fnaAlu
        End Get
        Set(ByVal value)
            fnaAlu = value
        End Set
    End Property

    Public Property gemaAlu
        Get
            Return emaAlu
        End Get
        Set(ByVal value)
            emaAlu = value
        End Set
    End Property

    Public Property gestado
        Get
            Return estado
        End Get
        Set(ByVal value)
            estado = value

        End Set
    End Property

    Public Function gcodAlu() As Object
        Throw New NotImplementedException()
    End Function

    Public Sub New()

    End Sub

    Public Sub New(ByVal dniAlu As String, ByVal nomAlu As String, ByVal apaAlu As String,
     ByVal amaAlu As String, ByVal edaAlu As String, ByVal sexAlu As String, ByVal telAlu As String, ByVal dirAlu As String,
     ByVal fnaAlu As Integer, ByVal emaAlu As Integer, ByVal esatdo As String)

        gdniAlu = dniAlu
        gnomAlu = nomAlu
        gapaAlu = apaAlu
        gamaAlu = amaAlu
        gedaAlu = edaAlu
        gsexAlu = sexAlu
        gtelAlu = telAlu
        gdirAlu = dirAlu
        gfnaAlu = fnaAlu
        gemaAlu = emaAlu
        gestado = estado
    End Sub
End Class

