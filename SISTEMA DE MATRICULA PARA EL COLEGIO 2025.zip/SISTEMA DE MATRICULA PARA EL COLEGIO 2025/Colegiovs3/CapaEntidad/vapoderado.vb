﻿Public Class vapoderado
    Dim dniApo, nomApo, apaApo, amaApo, sexApo, dirApo, fnaApo, ocuApo, eciApo, ginApo As String
    Dim edaApo, telApo As Integer

    Public Property gdniApo
        Get
            Return dniApo

        End Get
        Set(ByVal value)
            dniApo = value
        End Set
    End Property

    Public Property gnomApo
        Get
            Return nomApo
        End Get
        Set(ByVal value)
            nomApo = value
        End Set
    End Property

    Public Property gapaApo
        Get
            Return apaApo
        End Get
        Set(ByVal value)
            apaApo = value
        End Set
    End Property

    Public Property gamaApo
        Get
            Return amaApo
        End Get
        Set(ByVal value)
            amaApo = value
        End Set
    End Property

    Public Property gedaApo
        Get
            Return edaApo
        End Get
        Set(ByVal value)
            edaApo = value
        End Set
    End Property

    Public Property gsexApo
        Get
            Return sexApo
        End Get
        Set(ByVal value)
            sexApo = value
        End Set
    End Property

    Public Property gtelApo
        Get
            Return telApo
        End Get
        Set(ByVal value)
            telApo = value

        End Set
    End Property

    Public Property gdirApo
        Get
            Return dirApo
        End Get
        Set(ByVal value)
            dirApo = value
        End Set
    End Property

    Public Property gfnaApo
        Get
            Return fnaApo
        End Get
        Set(ByVal value)
            fnaApo = value
        End Set
    End Property

    Public Property gocuApo
        Get
            Return ocuApo
        End Get
        Set(ByVal value)
            ocuApo = value
        End Set
    End Property

    Public Property geciApo
        Get
            Return eciApo
        End Get
        Set(ByVal value)
            eciApo = value
        End Set
    End Property
    Public Property gginApo
        Get
            Return ginApo
        End Get
        Set(ByVal value)
            ginApo = value
        End Set
    End Property
    Public Function gcodApo() As Object
        Throw New NotImplementedException()
    End Function


    Public Sub New()

    End Sub

    Public Sub New(ByVal dniApo As String, ByVal nomApo As String, ByVal apaApo As String,
     ByVal amaApo As String, ByVal edaApo As Integer, ByVal sexApo As String, ByVal telApo As Integer, ByVal dirApo As String,
     ByVal fnaApo As String, ByVal ocuApo As String, ByVal eciApo As String, ByVal ginApo As String)

        gdniApo = dniApo
        gnomApo = nomApo
        gapaApo = apaApo
        gamaApo = amaApo
        gedaApo = edaApo
        gsexApo = sexApo
        gtelApo = telApo
        gdirApo = dirApo
        gfnaApo = fnaApo
        gocuApo = ocuApo
        geciApo = eciApo
        gginApo = ginApo
    End Sub
End Class
