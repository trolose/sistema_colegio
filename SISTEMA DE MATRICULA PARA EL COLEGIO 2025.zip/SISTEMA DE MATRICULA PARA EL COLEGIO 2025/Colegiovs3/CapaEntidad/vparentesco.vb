﻿Public Class vparentesco
    Dim parPar As String
    Dim codPar,dniAlu, dniApo As Integer

    Public Property gcodPar
        Get
            Return codPar

        End Get
        Set(ByVal value)
            codPar = value
        End Set
    End Property

    Public Property gparPar
        Get
            Return parPar

        End Get
        Set(ByVal value)
            parPar = value
        End Set
    End Property

    Public Property gdniAlu
        Get
            Return dniAlu

        End Get
        Set(ByVal value)
            dniAlu = value
        End Set
    End Property

    Public Property gdniApo
        Get
            Return dniApo

        End Get
        Set(ByVal value)
            dniApo = value
        End Set
    End Property
    Public Sub New()

    End Sub

    Public Sub New(ByVal codPar As Integer, ByVal parPar As String, ByVal dniAlu As Integer, ByVal dniApo As Integer)
        gcodPar = codPar
        gparPar = parPar
        gdniAlu = dniAlu
        gdniApo = dniApo
    End Sub

End Class
