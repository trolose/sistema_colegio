﻿Public Class vhorario
    Dim diaHor, hinHor, HfiHor, secHor, codCur As String
    Dim codHor, codAul, dniDoc As Integer

    Public Property gcodHor
        Get
            Return codHor

        End Get
        Set(ByVal value)
            codHor = value
        End Set
    End Property

    Public Property gdiaHor
        Get
            Return diaHor

        End Get
        Set(ByVal value)
            diaHor = value
        End Set
    End Property
    Public Property ghinHor
        Get
            Return hinHor

        End Get
        Set(ByVal value)
            hinHor = value
        End Set
    End Property
    Public Property gHfiHor
        Get
            Return HfiHor

        End Get
        Set(ByVal value)
            HfiHor = value
        End Set
    End Property
    Public Property gsecHor
        Get
            Return secHor

        End Get
        Set(ByVal value)
            secHor = value
        End Set
    End Property
    Public Property gcodAul
        Get
            Return codAul

        End Get
        Set(ByVal value)
            codAul = value
        End Set
    End Property
    Public Property gdniDoc
        Get
            Return dniDoc

        End Get
        Set(ByVal value)
            dniDoc = value
        End Set
    End Property
    Public Property gcodCur
        Get
            Return codCur

        End Get
        Set(ByVal value)
            codCur = value
        End Set
    End Property
    Public Sub New()

    End Sub

    Public Sub New(ByVal codHor As Integer, ByVal diaHor As String, ByVal hinHor As String,
     ByVal HfiHor As String, ByVal secHor As String, ByVal codAul As Integer, ByVal dniDoc As Integer, ByVal codCur As Integer)

        gcodHor = codHor
        gdiaHor = diaHor
        ghinHor = hinHor
        gHfiHor = HfiHor
        gsecHor = secHor
        gcodAul = codAul
        gdniDoc = dniDoc
        gcodCur = codCur
    End Sub

End Class
