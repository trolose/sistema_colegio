﻿Public Class vmatricula
    Dim fecMat, secMat, numAes As String
    Dim codMat, monMat, graMat, codAul, dniAlu As Integer

    Public Property gcodMat
        Get
            Return codMat

        End Get
        Set(ByVal value)
            codMat = value
        End Set
    End Property

    Public Property gfecMat
        Get
            Return fecMat

        End Get
        Set(ByVal value)
            fecMat = value
        End Set
    End Property

    Public Property gmonMat
        Get
            Return monMat

        End Get
        Set(ByVal value)
            monMat = value
        End Set
    End Property

    Public Property ggraMat
        Get
            Return graMat

        End Get
        Set(ByVal value)
            graMat = value
        End Set
    End Property

    Public Property gsecMat
        Get
            Return secMat

        End Get
        Set(ByVal value)
            secMat = value
        End Set
    End Property

    Public Property gcodAul
        Get
            Return codAul

        End Get
        Set(ByVal value)
            codAul = value
        End Set
    End Property

    Public Property gdniAlu
        Get
            Return dniAlu

        End Get
        Set(ByVal value)
            dniAlu = value
        End Set
    End Property

    Public Property gnumAes
        Get
            Return numAes

        End Get
        Set(ByVal value)
            numAes = value
        End Set
    End Property
    Public Sub New(ByVal codMat As Integer, ByVal fecMat As String, ByVal monMat As Integer, ByVal graMat As Integer,
                   ByVal secMat As String, ByVal codAul As Integer, ByVal dniAlu As Integer, ByVal numAes As String)

        gcodMat = codMat
        gfecMat = fecMat
        gmonMat = monMat
        ggraMat = graMat
        gsecMat = secMat
        gcodAul = codAul
        gdniAlu = dniAlu
        gnumAes = numAes

    End Sub

    Public Sub New()

    End Sub

End Class
