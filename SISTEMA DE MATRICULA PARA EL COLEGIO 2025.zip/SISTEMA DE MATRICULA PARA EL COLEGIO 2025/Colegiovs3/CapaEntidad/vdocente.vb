﻿Public Class vdocente
    Dim dniDoc, nomDoc, apaDoc, amaDoc, sexDoc, dirDoc, fnaDoc, emaDoc, espDoc As String
    Dim edaDoc, telDoc As Integer

    Public Property gdniDoc
        Get
            Return dniDoc

        End Get
        Set(ByVal value)
            dniDoc = value
        End Set
    End Property

    Public Property gnomDoc
        Get
            Return nomDoc
        End Get
        Set(ByVal value)
            nomDoc = value
        End Set
    End Property

    Public Property gapaDoc
        Get
            Return apaDoc
        End Get
        Set(ByVal value)
            apaDoc = value
        End Set
    End Property

    Public Property gamaDoc
        Get
            Return amaDoc
        End Get
        Set(ByVal value)
            amaDoc = value
        End Set
    End Property

    Public Property gedaDoc
        Get
            Return edaDoc
        End Get
        Set(ByVal value)
            edaDoc = value
        End Set
    End Property

    Public Property gsexDoc
        Get
            Return sexDoc
        End Get
        Set(ByVal value)
            sexDoc = value
        End Set
    End Property

    Public Property gtelDoc
        Get
            Return telDoc
        End Get
        Set(ByVal value)
            telDoc = value

        End Set
    End Property

    Public Property gdirDoc
        Get
            Return dirDoc
        End Get
        Set(ByVal value)
            dirDoc = value
        End Set
    End Property

    Public Property gfnaDoc
        Get
            Return fnaDoc
        End Get
        Set(ByVal value)
            fnaDoc = value
        End Set
    End Property

    Public Property gemaDoc
        Get
            Return emaDoc
        End Get
        Set(ByVal value)
            emaDoc = value
        End Set
    End Property

    Public Property gespDoc
        Get
            Return espDoc
        End Get
        Set(ByVal value)
            espDoc = value

        End Set
    End Property



    Public Sub New()

    End Sub

    Public Sub New(ByVal dniDoc As String, ByVal nomDoc As String, ByVal apaDoc As String,
     ByVal amaDoc As String, ByVal edaDoc As Integer, ByVal sexDoc As String, ByVal telDoc As Integer, ByVal dirDoc As String,
     ByVal fnaDoc As String, ByVal emaDoc As String, ByVal espDoc As String)

        gdniDoc = dniDoc
        gnomDoc = nomDoc
        gapaDoc = apaDoc
        gamaDoc = amaDoc
        gedaDoc = edaDoc
        gsexDoc = sexDoc
        gtelDoc = telDoc
        gdirDoc = dirDoc
        gfnaDoc = fnaDoc
        gemaDoc = emaDoc
        gespDoc = espDoc
    End Sub
End Class
