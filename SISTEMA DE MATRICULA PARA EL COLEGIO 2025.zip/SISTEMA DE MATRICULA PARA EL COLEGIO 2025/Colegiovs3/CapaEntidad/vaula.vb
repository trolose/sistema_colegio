﻿Public Class vaula
    Dim codAul, capAul, vliAul As Integer

    Public Property gcodAul
        Get
            Return codAul

        End Get
        Set(ByVal value)
            codAul = value
        End Set
    End Property

    Public Property gcapAul
        Get
            Return capAul
        End Get
        Set(ByVal value)
            capAul = value
        End Set
    End Property

    Public Property gvliAul
        Get
            Return vliAul
        End Get
        Set(ByVal value)
            vliAul = value
        End Set
    End Property

    Public Sub New()

    End Sub
    Public Sub New(ByVal codAul As Integer, ByVal capAul As Integer, ByVal vliAul As Integer)

        gcodAul = codAul
        gcapAul = capAul
        gvliAul = vliAul


    End Sub
End Class
