﻿Public Class ELogin
    Dim id As String
    Dim contraseña As String
    Dim tipo As String
    Public Property usuario
        Get
            Return id
        End Get
        Set(ByVal value)
            id = value
        End Set
    End Property
    Public Property pass
        Get
            Return contraseña
        End Get
        Set(ByVal value)
            contraseña = value
        End Set
    End Property

    Public Property tipousuario
        Get
            Return tipo
        End Get
        Set(ByVal value)
            tipo = value
        End Set
    End Property
    Public Sub New(ByVal usuario As String, ByVal pass As String, ByVal rol As String)
        usuario = usuario
        pass = pass
        tipousuario = rol
    End Sub
    Public Sub New()
    End Sub
End Class
