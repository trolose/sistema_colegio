﻿Public Class vañoescolar
    Dim numAes, finiAes, fteAes As String

    Public Property gnumAes
        Get
            Return numAes

        End Get
        Set(ByVal value)
            numAes = value
        End Set
    End Property
    Public Property gfiniAes
        Get
            Return finiAes

        End Get
        Set(ByVal value)
            finiAes = value
        End Set
    End Property
    Public Property gfteAes
        Get
            Return fteAes

        End Get
        Set(ByVal value)
            fteAes = value
        End Set
    End Property
    Public Sub New(ByVal numAes As Integer, ByVal finiAes As String, ByVal fteAes As String)
        gnumAes = numAes
        gfiniAes = finiAes
        gfteAes = fteAes
    End Sub

    Public Sub New()

    End Sub

End Class
