﻿Imports CapaDatos
Imports CapaEntidad
Public Class frmaula
    Private dt As New DataTable
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        menuprincipal.Show()
        Me.Hide()
    End Sub
    Private Sub mostraraula()
        Try
            Dim func As New faula
            dt = func.mostraraula



            If dt.Rows.Count <> 0 Then
                datalistado.DataSource = dt
                txtbuscar.Enabled = True
                datalistado.ColumnHeadersVisible = True
                inexistente.Visible = False
            Else
                datalistado.DataSource = Nothing
                txtbuscar.Enabled = False
                datalistado.ColumnHeadersVisible = False
                inexistente.Visible = True
            End If

        Catch ex As Exception

            MsgBox(ex.Message)
        End Try
        btnnuevo.Visible = True
        btneditar.Visible = False

        buscar()
    End Sub
    Private Sub buscar()
        Try
            Dim ds As New DataSet
            ds.Tables.Add(dt.Copy)
            Dim dv As New DataView(ds.Tables(0))

            dv.RowFilter = String.Format("Convert (codAul,'System.String')", cbocampo.Text) & " like '%" & txtbuscar.Text & "%'"

            If dv.Count <> 0 Then
                inexistente.Visible = False
                datalistado.DataSource = dv

            Else
                inexistente.Visible = True
                datalistado.DataSource = Nothing

            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Public Sub limpiar()

        btnregistrar.Visible = True
        btneditar.Visible = False
        txtcodigo.Text = ""
        txtcapacidad.Text = ""
        txtvli.Text = ""
    End Sub


    Private Sub btnnuevo_Click(sender As Object, e As EventArgs) Handles btnnuevo.Click
        limpiar()
        mostraraula()
    End Sub

    Private Sub btnregistrar_Click(sender As Object, e As EventArgs) Handles btnregistrar.Click
        If Me.ValidateChildren = True And txtcodigo.Text <> "" And txtcapacidad.Text <> "" And txtvli.Text <> "" Then
            Try
                Dim dts As New vaula
                Dim func As New faula


                dts.gcodAul = txtcodigo.Text
                dts.gcapAul = txtcapacidad.Text
                dts.gvliAul = txtvli.Text



                If func.insertaraula(dts) Then
                    MessageBox.Show("Aula registrado correctamente", "Guardando registros", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    mostraraula()
                    limpiar()
                Else
                    MessageBox.Show("Aula no fue registrado intente de nuevo ", "Guardando registros", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    mostraraula()
                    limpiar()

                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Else
            MessageBox.Show("Faltan ingresar datos ", "Guardando datos", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub btneditar_Click(sender As Object, e As EventArgs) Handles btneditar.Click
        Dim result As DialogResult
        result = MessageBox.Show("Realmente desea editar las aulas", "Modificando registros ", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
        If Me.ValidateChildren = True And txtcodigo.Text <> "" And txtcapacidad.Text <> "" And txtvli.Text <> "" Then
            Try
                Dim dts As New vaula
                Dim func As New faula


                dts.gcodAul = txtcodigo.Text
                dts.gcapAul = txtcapacidad.Text
                dts.gvliAul = txtvli.Text

                If func.editarnota(dts) Then
                    MessageBox.Show("Aula modificado correctamente", "Modificando registros", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    mostraraula()
                    limpiar()
                Else
                    MessageBox.Show("Aula no fue modificado intente de nuevo ", "Modificando registros", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    mostraraula()
                    limpiar()
                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Else
            MessageBox.Show("Faltan ingresar datos ", "Guardando datos", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

    End Sub

    Private Sub datalistado_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles datalistado.CellClick
        txtcodigo.Text = datalistado.CurrentRow.Cells(0).Value
        txtcapacidad.Text = datalistado.CurrentRow.Cells(1).Value
        txtvli.Text = datalistado.CurrentRow.Cells(2).Value
        btneditar.Visible = True
        btnregistrar.Visible = False

    End Sub


End Class