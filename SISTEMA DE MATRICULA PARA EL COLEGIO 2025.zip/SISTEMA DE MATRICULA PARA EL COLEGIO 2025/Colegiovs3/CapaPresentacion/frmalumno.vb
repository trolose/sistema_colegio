﻿Imports System.Data.SqlClient
Imports System.Data
Imports CapaDatos
Imports CapaEntidad
Imports System.Text.RegularExpressions

Public Class frmalumno
    Private dt As New DataTable
    Public Property DateTimePicker1 As Object
    Public Property bcx As Object

    Private Sub frmalumno_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        mostraralumno()
    End Sub


    Public Sub limpiar()
        btnregistrar.Visible = True
        btneditar.Visible = False
        txtdni.Text = ""
        txtnombre.Text = ""
        txtapa.Text = ""
        txtama.Text = ""
        txteda.Text = ""
        ComboBox1.Text = ""
        txttel.Text = ""
        txtdir.Text = ""

        txtema.Text = ""
        cbxestado.Text = ""
    End Sub
    Public Sub limpiarduplicado()
        txtdni.Text = ""
        txttel.Text = ""
    End Sub
    Private Sub mostraralumno()
        Try
            Dim func As New falumno
            dt = func.mostraralumno
            datalistado.Columns.Item("Eliminar").Visible = False


            If dt.Rows.Count <> 0 Then
                datalistado.DataSource = dt
                txtbuscar.Enabled = True
                datalistado.ColumnHeadersVisible = True
                inexistente.Visible = False
            Else
                datalistado.DataSource = Nothing
                txtbuscar.Enabled = False
                datalistado.ColumnHeadersVisible = False
                inexistente.Visible = True
            End If



        Catch ex As Exception

            MsgBox(ex.Message)
        End Try
        btnnuevo.Visible = True
        btneditar.Visible = False

        buscardnialumno()
    End Sub

    Private Sub buscardnialumno()
        Try
            Dim ds As New DataSet
            ds.Tables.Add(dt.Copy)
            Dim dv As New DataView(ds.Tables(0))

            dv.RowFilter = String.Format("Convert (dniAlu,'System.String')", cbcampo.Text) & " like '%" & txtbuscar.Text & "%'"

            If dv.Count <> 0 Then
                inexistente.Visible = False
                datalistado.DataSource = dv

            Else
                inexistente.Visible = True
                datalistado.DataSource = Nothing

            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnnuevo_Click(sender As Object, e As EventArgs) Handles btnnuevo.Click
        limpiar()
        Me.Width = 1150
        txtdni.Focus()
        mostraralumno()
        If txtdni.Enabled = True Then
        Else
            txtdni.Enabled = True
        End If

    End Sub

    Private Sub btnregistrar_Click(sender As Object, e As EventArgs) Handles btnregistrar.Click
        If Me.ValidateChildren = True And txtdni.Text <> "" And txtnombre.Text <> "" And txtapa.Text <> "" And txtama.Text <>
                     "" And txteda.Text <> "" And ComboBox1.Text <> "" And txttel.Text <> "" And txtdir.Text <> "" And FnaPerDateTimePicker.Text <> "" And txtema.Text <> "" And cbxestado.Text <> "" Then
            Try
                Dim dts As New valumno
                Dim func As New falumno



                dts.gdniAlu = txtdni.Text
                dts.gnomAlu = txtnombre.Text
                dts.gapaAlu = txtapa.Text
                dts.gamaAlu = txtama.Text
                dts.gedaAlu = txteda.Text
                dts.gsexAlu = ComboBox1.Text
                dts.gtelAlu = txttel.Text
                dts.gdirAlu = txtdir.Text
                dts.gfnaAlu = FnaPerDateTimePicker.Text
                dts.gemaAlu = txtema.Text
                dts.gestado = cbxestado.Text


                If func.insertaralumno(dts) Then
                    MessageBox.Show("Alumno registrado correctamente", "Guardando registros", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    MessageBox.Show("Seleccione su registro para definir parentesco y luego iniciar matrìcula", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    mostraralumno()
                    limpiar()
                Else
                    MessageBox.Show("Alumno no fue registrado intente de nuevo ", "Guardando registros", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    mostraralumno()
                    limpiarduplicado()

                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Else
            MessageBox.Show("Faltan ingresar datos ", "Guardando datos", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If


    End Sub



    Private Sub datalistado_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles datalistado.CellContentClick
        If e.ColumnIndex = Me.datalistado.Columns.Item("Eliminar").Index Then
            Dim chkcell As DataGridViewCheckBoxCell = Me.datalistado.Rows(e.RowIndex).Cells("Eliminar")
            chkcell.Value = Not chkcell.Value
        End If
    End Sub

    Private Sub btneliminar_Click(sender As Object, e As EventArgs) Handles btneliminar.Click
        Dim result As DialogResult
        result = MessageBox.Show("¿Realmente quiere eliminar a los alumnos seleccionados?", "Eliminando registros ", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
        If result = DialogResult.OK Then
            Try
                For Each row As DataGridViewRow In datalistado.Rows
                    Dim marcado As Boolean = Convert.ToBoolean(row.Cells("Eliminar").Value)
                    If marcado Then
                        Dim onekey As Integer = Convert.ToInt32(row.Cells("dniAlu").Value)
                        Dim vdb As New valumno
                        Dim func As New falumno
                        vdb.gdniAlu = onekey

                        If func.eliminaralumno(vdb) Then
                        Else
                            MessageBox.Show("Alumno no eliminado", "Eliminando registros ", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        End If
                    End If

                Next
                Call mostraralumno()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Else
            MessageBox.Show("Cancelando eliminacion de registros", "Eliminando registros ", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Call mostraralumno()
        End If
        Call limpiar()
    End Sub


    Private Sub datalistado_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles datalistado.CellClick
        Dim I As String = e.RowIndex
        frmparentesco.txtdnialu.Text = datalistado.Rows(I).Cells(1).Value.ToString
        Dim A As String = e.RowIndex
        frmmatricula.txtalumno.Text = datalistado.Rows(A).Cells(1).Value

        txtdni.Text = datalistado.SelectedCells.Item(1).Value
        txtnombre.Text = datalistado.SelectedCells.Item(2).Value
        txtapa.Text = datalistado.SelectedCells.Item(3).Value
        txtama.Text = datalistado.SelectedCells.Item(4).Value
        txteda.Text = datalistado.SelectedCells.Item(5).Value
        ComboBox1.Text = datalistado.SelectedCells.Item(6).Value
        txttel.Text = datalistado.SelectedCells.Item(7).Value
        txtdir.Text = datalistado.SelectedCells.Item(8).Value
        FnaPerDateTimePicker.Text = datalistado.SelectedCells.Item(9).Value
        txtema.Text = datalistado.SelectedCells.Item(10).Value
        cbxestado.Text = datalistado.SelectedCells.Item(11).Value
        btneditar.Visible = True
        btnregistrar.Visible = False
        If txtdni.Enabled = False Then
        Else
            txtdni.Enabled = False
        End If
    End Sub


    Private Sub btneditar_Click(sender As Object, e As EventArgs) Handles btneditar.Click
        Dim result As DialogResult
        result = MessageBox.Show("Realmente desea editar los datos del alumno", "Modificando registros ", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
        If result = DialogResult.OK Then

            If Me.ValidateChildren = True And txtdni.Text <> "" And txtnombre.Text <> "" And txtapa.Text <> "" And txtama.Text <>
                     "" And txteda.Text <> "" And ComboBox1.Text <> "" And txttel.Text <> "" And txtdir.Text <> "" And FnaPerDateTimePicker.Text <> "" And txtema.Text <> "" And cbxestado.Text <> "" Then
                Try
                    Dim dts As New valumno
                    Dim func As New falumno
                    If txtdni.Enabled = False Then

                    Else
                        txtdni.Enabled = True

                    End If

                    dts.gdniAlu = txtdni.Text
                    dts.gnomAlu = txtnombre.Text
                    dts.gapaAlu = txtapa.Text
                    dts.gamaAlu = txtama.Text
                    dts.gedaAlu = txteda.Text
                    dts.gsexAlu = ComboBox1.Text
                    dts.gtelAlu = txttel.Text
                    dts.gdirAlu = txtdir.Text
                    dts.gfnaAlu = FnaPerDateTimePicker.Text
                    dts.gemaAlu = txtema.Text
                    dts.gestado = cbxestado.Text


                    If func.editaralumno(dts) Then
                        MessageBox.Show("Alumno modificado correctamente", "Modificando registros", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        mostraralumno()
                        limpiar()
                    Else
                        MessageBox.Show("Alumno no fue modificado intente de nuevo ", "Modificando registros", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        mostraralumno()
                        limpiar()

                    End If
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try
            Else
                MessageBox.Show("Faltan ingresar datos ", "Guardando datos", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        End If

    End Sub

    Private Sub cbeliminar_CheckedChanged(sender As Object, e As EventArgs) Handles cbeliminar.CheckedChanged
        If cbeliminar.CheckState = CheckState.Checked Then
            datalistado.Columns.Item("Eliminar").Visible = True
        Else

            datalistado.Columns.Item("Eliminar").Visible = False
        End If
    End Sub

    Private Sub txttel_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txttel.KeyPress
        If (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If




    End Sub

    Private Sub txteda_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txteda.KeyPress
        If (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If




    End Sub

    Private Sub txtdni_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtdni.KeyPress
        If (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If



    End Sub

    Private Sub txtnombre_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtnombre.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If



    End Sub

    Private Sub txtapa_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtapa.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

    End Sub

    Private Sub txtama_TextChanged(sender As Object, e As EventArgs) Handles txtama.TextChanged

    End Sub

    Private Sub txtama_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtama.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If
    End Sub



    Private Sub btnregresar_Click(sender As Object, e As EventArgs)
        menuprincipal.Show()
        Me.Hide()
    End Sub



    Private Sub txtdni_Validated(sender As Object, e As EventArgs) Handles txtdni.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
        'solo acepte 8 digitos si es menos sale el mensaje
        If Len(txtdni.Text) < 8 Then
            btnregistrar.Visible = False
            MessageBox.Show("Faltan digitos al DNI", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            btnregistrar.Visible = True
        End If
    End Sub



    Private Sub txtapa_TextChanged(sender As Object, e As EventArgs) Handles txtapa.TextChanged

    End Sub

    Private Sub txtnombre_Validated(sender As Object, e As EventArgs) Handles txtnombre.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
        If Len(txtnombre.Text) < 2 Then
            btnregistrar.Visible = False
            MessageBox.Show("Insertar mas  2 caracteres ", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            btnregistrar.Visible = True
        End If
    End Sub

    Private Sub txtapa_Validated(sender As Object, e As EventArgs) Handles txtapa.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
        If Len(txtapa.Text) < 2 Then
            btnregistrar.Visible = False
            MessageBox.Show("Insertar mas  2 caracteres ", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            btnregistrar.Visible = True
        End If
    End Sub

    Private Sub txtama_Validated(sender As Object, e As EventArgs) Handles txtama.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
        If Len(txtama.Text) < 2 Then
            btnregistrar.Visible = False
            MessageBox.Show("Insertar mas  2 caracteres ", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            btnregistrar.Visible = True
        End If
    End Sub

    Private Sub txteda_TextChanged(sender As Object, e As EventArgs) Handles txteda.TextChanged

    End Sub

    Private Sub txteda_Validated(sender As Object, e As EventArgs) Handles txteda.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
    End Sub

    Private Sub txtsex_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub txtsex_Validated(sender As Object, e As EventArgs)
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
    End Sub



    Private Sub txttel_Validated(sender As Object, e As EventArgs) Handles txttel.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
        If Len(txttel.Text) < 9 Then
            btnregistrar.Visible = False
            MessageBox.Show("Faltan digitos", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            btnregistrar.Visible = True
        End If
    End Sub

    Private Sub txtdir_TextChanged(sender As Object, e As EventArgs) Handles txtdir.TextChanged

    End Sub

    Private Sub txtdir_Validated(sender As Object, e As EventArgs) Handles txtdir.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
        If Len(txtnombre.Text) < 2 Then
            btnregistrar.Visible = False
            MessageBox.Show("Escribir correctamente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            btnregistrar.Visible = True
        End If
    End Sub

    Private Sub txtfna_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub txtfna_Validated(sender As Object, e As EventArgs)
        If DirectCast(sender, DateTimePicker).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
    End Sub

    Private Sub txtema_TextChanged(sender As Object, e As EventArgs) Handles txtema.TextChanged
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
    End Sub

    Private Sub btnsalir_Click(sender As Object, e As EventArgs) Handles btnsalir.Click
        menuprincipal.Show()
        Me.Hide()

    End Sub

    Private Sub btnimprimir_Click(sender As Object, e As EventArgs) Handles btnimprimir.Click
        ReporteAlumno.Show()

    End Sub

    Private Sub txtbuscar_TextChanged(sender As Object, e As EventArgs) Handles txtbuscar.TextChanged
        buscardnialumno()
    End Sub


    Private Sub Conectado()
        Throw New NotImplementedException()
    End Sub

    Private Sub FnaPerDateTimePicker_ValueChanged_1(sender As Object, e As EventArgs) Handles FnaPerDateTimePicker.ValueChanged
        Dim FECHANAC As Date
        Dim EDAD As Integer
        FECHANAC = FnaPerDateTimePicker.Value
        EDAD = Now.Year() - FECHANAC.Year
        If FECHANAC <= "01/01/2005" Or FECHANAC >= "01/12/2013" Then
            MsgBox("Edad No Permitida Para Realizar Una Matrícula")
            txteda.Clear()
            FnaPerDateTimePicker.Value = "01/02/2012"
        Else
            txteda.Text = CStr(EDAD)
        End If
    End Sub
    Private Function validar_Mail(ByVal sMail As String) As Boolean
        ' retorna true o false   
        Return Regex.IsMatch(sMail,
        "^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$")
    End Function

    Private Sub txtcorreo_Leave(sender As Object, e As EventArgs) Handles txtema.Leave
        If validar_Mail(LCase(txtema.Text)) = False Then
            MessageBox.Show("Dirección de correo electronico no valida,el correo debe tener el formato: nombre@ejemplo.com, " & "por favor seleccione un correo valido", "Validación de correo electronico", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            txtema.Focus()
            txtema.SelectAll()

        End If

    End Sub

    Private Sub txtdni_TextChanged(sender As Object, e As EventArgs) Handles txtdni.TextChanged

    End Sub

    Private Sub iniciar_CheckedChanged(sender As Object, e As EventArgs) Handles iniciar.CheckedChanged
        If iniciar.Checked = True Then
            btnregistrar.Enabled = True

            txtdni.Enabled = True
            txtnombre.Enabled = True
            txtapa.Enabled = True
            txtama.Enabled = True
            FnaPerDateTimePicker.Enabled = True
            ComboBox1.Enabled = True
            txtdir.Enabled = True
            txttel.Enabled = True
            txtema.Enabled = True
            cbxestado.Enabled = True


            txtdni.Focus()
        Else
            txtdni.Enabled = False
            txtnombre.Enabled = False
            txtapa.Enabled = False
            txtama.Enabled = False
            FnaPerDateTimePicker.Enabled = False
            ComboBox1.Enabled = False
            txtdir.Enabled = False
            txttel.Enabled = False
            txtema.Enabled = False
            cbxestado.Enabled = False

            btnregistrar.Enabled = False
        End If
    End Sub

    Private Sub cbxestado_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cbxestado.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        End If
    End Sub

    Private Sub ComboBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ComboBox1.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        End If
    End Sub
End Class







