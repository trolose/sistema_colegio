﻿Public Class LoginCarga
    Private Sub LoginCarga_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ProgressBar1.Increment(3)
        lblmensaje.Text = "CARGANDO EL SISTEMA AL " & ProgressBar1.Value & "%"
        If ProgressBar1.Value = 100 Then
            Timer2.Start()
        End If
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Me.Opacity = Me.Opacity = 0.1
        If Me.Opacity <= 0 Then
            Me.Hide()
            menuprincipal.Show()
            Timer1.Stop()
            Timer2.Stop()

        End If
    End Sub
End Class