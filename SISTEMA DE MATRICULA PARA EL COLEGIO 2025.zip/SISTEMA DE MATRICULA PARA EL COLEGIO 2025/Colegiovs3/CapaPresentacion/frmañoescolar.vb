﻿Imports System.Data.SqlClient
Imports CapaDatos
Imports CapaEntidad
Public Class frmañoescolar
    Private dt As New DataTable
    Public Property CMD As Object
    Private Sub mostrarañoescolar()
        Try
            Dim func As New fañoescolar
            dt = func.mostrarañoescolar
            datalistado.Columns.Item("Eliminar").Visible = False


            If dt.Rows.Count <> 0 Then
                datalistado.DataSource = dt
                'txtbuscar.Enabled = True
                datalistado.ColumnHeadersVisible = True
                inexistente.Visible = False
            Else
                datalistado.DataSource = Nothing
                'txtbuscar.Enabled = False
                datalistado.ColumnHeadersVisible = False
                inexistente.Visible = True
            End If



        Catch ex As Exception

            MsgBox(ex.Message)
        End Try
        btnnuevo.Visible = True
        btneditar.Visible = False

        'buscardniapoderado()
    End Sub


    Private Sub frmañoescolar_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        mostrarañoescolar()
    End Sub



    Public Sub limpiar()
        btnregistrar.Visible = True
        btneditar.Visible = False
        txtaes.Text = ""
        DateTimePicker1.Text = ""
        DateTimePicker2.Text = ""

    End Sub



    Private Sub btnnuevo_Click(sender As Object, e As EventArgs) Handles btnnuevo.Click
        limpiar()
        mostrarañoescolar()
        If txtaes.Enabled = True Then
        Else
            txtaes.Enabled = True
        End If
    End Sub

    Private Sub btnregistrar_Click(sender As Object, e As EventArgs) Handles btnregistrar.Click
        If Me.ValidateChildren = True And txtaes.Text <> "" And DateTimePicker1.Text <> "" And DateTimePicker2.Text <> "" Then
            Try
                Dim dts As New vañoescolar
                Dim func As New fañoescolar

                dts.gnumAes = txtaes.Text
                dts.gfiniAes = DateTimePicker1.Text
                dts.gfteAes = DateTimePicker2.Text





                If func.insertaraño(dts) Then
                    MessageBox.Show("Año escolar registrado correctamente", "Guardando registros", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    mostrarañoescolar()
                    limpiar()
                Else
                    MessageBox.Show("Año escolar no registrado intente de nuevo ", "Guardando registros", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    mostrarañoescolar()
                    limpiar()


                End If
            Catch ex As Exception

                MsgBox(ex.Message)
            End Try
        Else
            MessageBox.Show("Faltan ingresar datos ", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)

        End If
    End Sub

    Private Sub btneliminar_Click(sender As Object, e As EventArgs) Handles btneliminar.Click
        Dim result As DialogResult
        result = MessageBox.Show("¿Realmente quiere eliminar el año escolar?", "Eliminando registros ", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
        If result = DialogResult.OK Then
            Try
                For Each row As DataGridViewRow In datalistado.Rows
                    Dim marcado As Boolean = Convert.ToBoolean(row.Cells("Eliminar").Value)
                    If marcado Then
                        Dim onekey As Integer = Convert.ToInt32(row.Cells("numAes").Value)
                        Dim vdb As New vañoescolar
                        Dim func As New fañoescolar
                        vdb.gnumAes = onekey

                        If func.eliminaraño(vdb) Then
                        Else
                            MessageBox.Show("Año escolar no eliminado", "Eliminando registros ", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        End If
                    End If

                Next
                Call mostrarañoescolar()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Else
            MessageBox.Show("Cancelando eliminacion de registros", "Eliminando registros ", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Call mostrarañoescolar()
        End If
        Call limpiar()
    End Sub

    Private Sub btneditar_Click(sender As Object, e As EventArgs) Handles btneditar.Click
        If Me.ValidateChildren = True And txtaes.Text <> "" And DateTimePicker1.Text <> "" And DateTimePicker2.Text <> "" Then
            Try
                Dim dts As New vañoescolar
                Dim func As New fañoescolar

                If txtaes.Enabled = False Then

                Else
                    txtaes.Enabled = True
                End If

                dts.gnumAes = txtaes.Text
                dts.gfiniAes = DateTimePicker1.Text
                dts.gfteAes = DateTimePicker2.Text



                If func.editaraño(dts) Then
                    MessageBox.Show("Año escolar modificado correctamente", "Modificando registros", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    mostrarañoescolar()
                    limpiar()
                Else
                    MessageBox.Show("Año escolar no fue modificado intente de nuevo ", "Modificando registros", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    mostrarañoescolar()
                    limpiar()

                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Else
            MessageBox.Show("Faltan ingresar datos ", "Guardando datos", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

    End Sub

    Private Sub cbeliminar_CheckedChanged(sender As Object, e As EventArgs) Handles cbeliminar.CheckedChanged
        If cbeliminar.CheckState = CheckState.Checked Then
            datalistado.Columns.Item("Eliminar").Visible = True
        Else

            datalistado.Columns.Item("Eliminar").Visible = False
        End If
    End Sub

    Private Sub datalistado_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles datalistado.CellContentClick
        If e.ColumnIndex = Me.datalistado.Columns.Item("Eliminar").Index Then
            Dim chkcell As DataGridViewCheckBoxCell = Me.datalistado.Rows(e.RowIndex).Cells("Eliminar")
            chkcell.Value = Not chkcell.Value
        End If
    End Sub

    Private Sub datalistado_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles datalistado.CellClick
        txtaes.Text = datalistado.SelectedCells.Item(1).Value
        DateTimePicker1.Text = datalistado.SelectedCells.Item(2).Value
        DateTimePicker2.Text = datalistado.SelectedCells.Item(3).Value

        If txtaes.Enabled = False Then
        Else
            txtaes.Enabled = False
        End If

        btneditar.Visible = True
        btnregistrar.Visible = False
    End Sub

    Private Sub btnregresar_Click(sender As Object, e As EventArgs) Handles btnregresar.Click
        menuprincipal.Show()
        Me.Hide()
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class