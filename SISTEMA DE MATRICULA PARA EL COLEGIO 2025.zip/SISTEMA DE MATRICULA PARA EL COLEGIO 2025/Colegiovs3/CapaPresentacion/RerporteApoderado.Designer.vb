﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class RerporteApoderado
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ReportDataSource1 As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource()
        Me.ReportViewer1 = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.uLTIMO = New CapaPresentacion.uLTIMO()
        Me.ApoderadoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ApoderadoTableAdapter = New CapaPresentacion.uLTIMOTableAdapters.ApoderadoTableAdapter()
        CType(Me.uLTIMO, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ApoderadoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ReportViewer1
        '
        Me.ReportViewer1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill
        ReportDataSource1.Name = "DataSet1"
        ReportDataSource1.Value = Me.ApoderadoBindingSource
        Me.ReportViewer1.LocalReport.DataSources.Add(ReportDataSource1)
        Me.ReportViewer1.LocalReport.ReportEmbeddedResource = "CapaPresentacion.Report5.rdlc"
        Me.ReportViewer1.Location = New System.Drawing.Point(0, 0)
        Me.ReportViewer1.Name = "ReportViewer1"
        Me.ReportViewer1.Size = New System.Drawing.Size(1128, 461)
        Me.ReportViewer1.TabIndex = 0
        '
        'uLTIMO
        '
        Me.uLTIMO.DataSetName = "uLTIMO"
        Me.uLTIMO.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ApoderadoBindingSource
        '
        Me.ApoderadoBindingSource.DataMember = "Apoderado"
        Me.ApoderadoBindingSource.DataSource = Me.uLTIMO
        '
        'ApoderadoTableAdapter
        '
        Me.ApoderadoTableAdapter.ClearBeforeFill = True
        '
        'RerporteApoderado
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1128, 461)
        Me.Controls.Add(Me.ReportViewer1)
        Me.Name = "RerporteApoderado"
        Me.Text = "RerporteApoderado"
        CType(Me.uLTIMO, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ApoderadoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ReportViewer1 As Microsoft.Reporting.WinForms.ReportViewer
    Friend WithEvents ApoderadoBindingSource As BindingSource
    Friend WithEvents uLTIMO As uLTIMO
    Friend WithEvents ApoderadoTableAdapter As uLTIMOTableAdapters.ApoderadoTableAdapter
End Class
