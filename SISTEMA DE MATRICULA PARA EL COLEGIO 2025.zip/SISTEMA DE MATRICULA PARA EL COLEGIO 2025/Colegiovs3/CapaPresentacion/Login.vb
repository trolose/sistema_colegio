﻿Imports System.Data.SqlClient
Public Class Login
    Private Sub btningresar_Click(sender As Object, e As EventArgs) Handles btningresar.Click
        Try
            Dim dts As New CapaEntidad.ELogin
            Dim func As New CapaDatos.Conexion
            dts.usuario = txtusuario.Text
            dts.pass= txtcontraseña.Text
            dts.tipousuario = cbtipo.SelectedValue
            If func.validar(dts) = True Then
                LoginCarga.Show()
                Me.Hide()
            Else
                MsgBox("Error, verificar la informacion", MsgBoxStyle.Information)
                txtusuario.Clear()
                txtcontraseña.Clear()
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnsalir_Click(sender As Object, e As EventArgs) Handles btnsalir.Click
        Dim resul As DialogResult
        resul = MessageBox.Show("Desea salir del sistema", "Sistema Colegio N° 2025", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation)
        If resul = DialogResult.OK Then
            MessageBox.Show("Hasta luego", "Sistema Colegio N° 2025", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Me.Close()
        End If
    End Sub
    Private Sub sqlcombo(ByVal combobox As ComboBox, ByVal sql As String)
        Dim ingresarsql As String = "Data Source = .; Initial Catalog = ColegioBD; Integrated Security=true"
        Dim conexion As New SqlConnection(ingresarsql)
        Try
            conexion.Open()
            Dim comand As New SqlCommand(sql, conexion)
            Dim da As New SqlDataAdapter(comand)
            Dim ds As New DataSet
            da.Fill(ds)
            combobox.DataSource = ds.Tables(0)
            combobox.DisplayMember = ds.Tables(0).Columns(1).ToString
            combobox.ValueMember = ds.Tables(0).Columns(0).Caption
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            If conexion.State = ConnectionState.Open Then
                conexion.Close()
            End If
        End Try
    End Sub
    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        sqlcombo(cbtipo, "Select codtipo, tiporol from tipousuario")

    End Sub

    Private Sub cbtipo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cbtipo.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        End If
    End Sub
End Class
