﻿Public Class ReporteParentesco
    Private Sub ReporteParentesco_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        Me.ReportViewer1.RefreshReport()
        Me.ParentescoTableAdapter.Fill(Me.uLTIMO.Parentesco)
    End Sub

    Private Sub ReportViewer1_Load(sender As Object, e As EventArgs) Handles ReportViewer1.Load

    End Sub
End Class