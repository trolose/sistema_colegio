﻿Imports CapaDatos
Imports CapaEntidad
Public Class frmmatricula
    Private dt As New DataTable
    Private Sub frmmatricula_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        mostrarmatricula()

    End Sub



    Public Sub limpiar()
        btnregistrar.Visible = True
        btnmodificar.Visible = False
        txtcodigo.Text = ""
        DateTimePicker1.Text = ""
        txtmonto.Text = ""
        txtgrado.Text = ""
        txtseccion.Text = ""
        txtaula.Text = ""
        txtalumno.Text = ""
        txtañoescolar.Text = ""
    End Sub
    Public Sub verifica()
        txtcodigo.Text = ""
        txtalumno.Text = ""
    End Sub

    Private Sub mostrarmatricula()
        Try
            Dim func As New fmatricula
            dt = func.mostrarmatricula
            datalistado.Columns.Item("Eliminar").Visible = False

            If dt.Rows.Count <> 0 Then
                datalistado.DataSource = dt
                txtbuscar.Enabled = True
                datalistado.ColumnHeadersVisible = True
                inexistente.Visible = False
            Else
                datalistado.DataSource = Nothing
                txtbuscar.Enabled = False
                datalistado.ColumnHeadersVisible = False
                inexistente.Visible = True
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        btnnuevo.Visible = True
        btnmodificar.Visible = False

        buscar()
    End Sub
    Private Sub buscar()
        Try
            Dim ds As New DataSet
            ds.Tables.Add(dt.Copy)
            Dim dv As New DataView(ds.Tables(0))
            dv.RowFilter = String.Format("Convert (codMat,'System.String')", cbcampo.Text) & " like '%" & txtbuscar.Text & "%'"



            If dv.Count <> 0 Then
                inexistente.Visible = False
                datalistado.DataSource = dv

            Else
                inexistente.Visible = False
                datalistado.DataSource = dv
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub



    Private Sub btnnuevo_Click(sender As Object, e As EventArgs) Handles btnnuevo.Click
        limpiar()
        Me.Width = 1030
        txtcodigo.Focus()
        mostrarmatricula()
    End Sub

    Private Sub btnregistrar_Click(sender As Object, e As EventArgs) Handles btnregistrar.Click
        If Me.ValidateChildren = True And txtcodigo.Text <> "" And DateTimePicker1.Text <> "" And txtmonto.Text <> "" And txtgrado.Text <>
                     "" And txtseccion.Text <> "" And txtaula.Text <> "" And txtalumno.Text <> "" And txtañoescolar.Text <> "" Then
            Try
                Dim dts As New vmatricula
                Dim func As New fmatricula

                dts.gcodMat = txtcodigo.Text
                dts.gfecMat = DateTimePicker1.Text
                dts.gmonMat = txtmonto.Text
                dts.ggraMat = txtgrado.Text
                dts.gsecMat = txtseccion.Text
                dts.gcodAul = txtaula.Text
                dts.gdniAlu = txtalumno.Text
                dts.gnumAes = txtañoescolar.Text

                If func.insertarmatricula(dts) Then
                    MessageBox.Show("matricula registrada correctamente", "Guardando registros", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    mostrarmatricula()
                    limpiar()
                Else
                    MessageBox.Show("matricula no fue registrada intente de nuevo ", "Guardando registros", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    mostrarmatricula()
                    verifica()

                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Else
            MessageBox.Show("Faltan ingresar datos ", "Guardando datos", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub datalistado_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)
        If e.ColumnIndex = Me.datalistado.Columns.Item("Eliminar").Index Then
            Dim chkcell As DataGridViewCheckBoxCell = Me.datalistado.Rows(e.RowIndex).Cells("Eliminar")
            chkcell.Value = Not chkcell.Value
        End If
    End Sub

    Private Sub btneliminar_Click(sender As Object, e As EventArgs) Handles btneliminar.Click
        Dim result As DialogResult
        result = MessageBox.Show("¿Realmente quiere eliminar las personas seleccionadas?", "Eliminando registros ", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
        If result = DialogResult.OK Then
            Try
                For Each row As DataGridViewRow In datalistado.Rows
                    Dim marcado As Boolean = Convert.ToBoolean(row.Cells("Eliminar").Value)
                    If marcado Then
                        Dim onekey As Integer = Convert.ToInt32(row.Cells("codMat").Value)
                        Dim vdb As New vmatricula
                        Dim func As New fmatricula
                        vdb.gcodMat = onekey

                        If func.eliminarmatricula(vdb) Then
                        Else
                            MessageBox.Show("Matricula no eliminada", "Eliminando registros ", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        End If
                    End If

                Next
                Call mostrarmatricula()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Else
            MessageBox.Show("Cancelando eliminacion de registros", "Eliminando registros ", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Call mostrarmatricula()
        End If
        Call limpiar()
    End Sub


    Private Sub btnmodificar_Click(sender As Object, e As EventArgs) Handles btnmodificar.Click

        Dim result As DialogResult
        result = MessageBox.Show("Realmente desea editar los datos de la persona", "Modificando registros ", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
        If result = DialogResult.OK Then

            If Me.ValidateChildren = True And txtcodigo.Text <> "" And DateTimePicker1.Text <> "" And txtmonto.Text <> "" And txtgrado.Text <>
                     "" And txtseccion.Text <> "" And txtaula.Text <> "" And txtalumno.Text <> "" And txtañoescolar.Text <> "" Then
                Try
                    Dim dts As New vmatricula
                    Dim func As New fmatricula


                    dts.gcodMat = txtcodigo.Text
                    dts.gfecMat = DateTimePicker1.Text
                    dts.gmonMat = txtmonto.Text
                    dts.ggraMat = txtgrado.Text
                    dts.gsecMat = txtseccion.Text
                    dts.gcodAul = txtaula.Text
                    dts.gdniAlu = txtalumno.Text
                    dts.gnumAes = txtañoescolar.Text

                    If func.actualizarmatricula(dts) Then
                        MessageBox.Show("matricula modificada correctamente", "Modificando registros", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        mostrarmatricula()
                        limpiar()
                    Else
                        MessageBox.Show("matricula no fue modificado intente de nuevo ", "Modificando registros", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        mostrarmatricula()
                        limpiar()

                    End If
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try
            Else
                MessageBox.Show("Faltan ingresar datos ", "Guardando datos", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        End If
    End Sub

    Private Sub btnregresar_Click(sender As Object, e As EventArgs) Handles btnregresar.Click
        menuprincipal.Show()
        Me.Hide()
    End Sub

    Private Sub txtcodigo_Validated(sender As Object, e As EventArgs)
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Ingrese el codigo de la matricula por favor estos datos son obligatorios ")
        End If
    End Sub

    Private Sub txtfecha_Validated(sender As Object, e As EventArgs)
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Ingrese la fecha de nacimiento de la matricula por favor estos datos son obligatorios ")
        End If
    End Sub

    Private Sub txtmonto_Validated(sender As Object, e As EventArgs)
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Ingrese el monto de la matricula por favor, estos datos son obligatorios ")
        End If
    End Sub

    Private Sub txtgrado_Validated(sender As Object, e As EventArgs)
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Ingrese el grado de la matricula por favor estos datos son obligatorios ")
        End If
    End Sub

    Private Sub txtseccion_Validated(sender As Object, e As EventArgs)
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Ingrese la seccion de la matricula por favor, estos datos son obligatorios ")
        End If
    End Sub

    Private Sub txtaula_Validated(sender As Object, e As EventArgs)
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Ingrese el aula de la matricula por favor, estos datos son obligatorios ")
        End If
    End Sub

    Private Sub txtalumno_Validated(sender As Object, e As EventArgs)
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Ingrese el codigo del alumno por favor, estos datos son obligatorios ")
        End If
    End Sub

    Private Sub txtañoescolar_Validated(sender As Object, e As EventArgs)
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Ingrese el año escolar de la matricula por favor, estos datos son obligatorios ")
        End If
    End Sub

    Private Sub cbeliminar_CheckedChanged(sender As Object, e As EventArgs) Handles cbeliminar.CheckedChanged
        If cbeliminar.CheckState = CheckState.Checked Then
            datalistado.Columns.Item("Eliminar").Visible = True
        Else

            datalistado.Columns.Item("Eliminar").Visible = False
        End If
    End Sub


    Private Sub txtmonto_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtmonto.KeyPress
        If (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsControl(e.KeyChar)) Then
            e.Handled = False
        End If
    End Sub


    Private Sub txtgrado_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtgrado.KeyPress
        If (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsControl(e.KeyChar)) Then
            e.Handled = False
        End If
    End Sub


    Private Sub txtaula_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtaula.KeyPress
        If (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsControl(e.KeyChar)) Then
            e.Handled = False
        End If
    End Sub

    Private Sub txtalumno_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtalumno.KeyPress
        If (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsControl(e.KeyChar)) Then
            e.Handled = False
        End If
    End Sub

    Private Sub txtañoescolar_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtañoescolar.KeyPress
        If (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsControl(e.KeyChar)) Then
            e.Handled = False
        End If
    End Sub

    Private Sub txtcodigo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtcodigo.KeyPress
        If (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsControl(e.KeyChar)) Then
            e.Handled = False
        End If
    End Sub



    Private Sub txtseccion_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtseccion.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsControl(e.KeyChar)) Then
            e.Handled = False
        End If
    End Sub

    Private Sub datalistado_CellContentClick_1(sender As Object, e As DataGridViewCellEventArgs) Handles datalistado.CellContentClick
        If e.ColumnIndex = Me.datalistado.Columns.Item("Eliminar").Index Then
            Dim chkcell As DataGridViewCheckBoxCell = Me.datalistado.Rows(e.RowIndex).Cells("Eliminar")
            chkcell.Value = Not chkcell.Value
        End If
    End Sub
    Private Sub datalistado_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles datalistado.CellClick
        txtcodigo.Text = datalistado.SelectedCells.Item(1).Value
        DateTimePicker1.Text = datalistado.SelectedCells.Item(2).Value
        txtmonto.Text = datalistado.SelectedCells.Item(3).Value
        txtgrado.Text = datalistado.SelectedCells.Item(4).Value
        txtseccion.Text = datalistado.SelectedCells.Item(5).Value
        txtaula.Text = datalistado.SelectedCells.Item(6).Value
        txtalumno.Text = datalistado.SelectedCells.Item(7).Value
        txtañoescolar.Text = datalistado.SelectedCells.Item(8).Value


        btnmodificar.Visible = True
        btnregistrar.Visible = False
    End Sub

    Private Sub btnimprimir_Click(sender As Object, e As EventArgs) Handles btnimprimir.Click
        ReporteMatricula.Show()
    End Sub
End Class