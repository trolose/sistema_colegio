﻿Imports System.Data.SqlClient
Imports System.Text.RegularExpressions
Imports CapaDatos
Imports CapaEntidad
Public Class frmdocente
    Private dt As New DataTable


    Private Sub frmdocente_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        mostrardocente()
    End Sub

    Public Sub limpiar()
        btnregistrar.Visible = True
        btneditar.Visible = False
        txtdni.Text = ""
        txtnombre.Text = ""
        txtapa.Text = ""
        txtama.Text = ""
        txtedad.Text = ""
        ComboBox1.Text = ""
        txttelefono.Text = ""
        txtdireccion.Text = ""
        FnaDocDateTimePicker1.Text = ""
        txtcorreo.Text = ""
        ComboBox2.Text = ""
    End Sub
    Public Sub limpiarduplicado()
        txtdni.Text = ""
        txttelefono.Text = ""

    End Sub



    Private Sub mostrardocente()
        Try
            Dim func As New fdocente
            dt = func.mostrardocente
            datalistado.Columns.Item("Eliminar").Visible = False


            If dt.Rows.Count <> 0 Then
                datalistado.DataSource = dt
                txtbuscar.Enabled = True
                datalistado.ColumnHeadersVisible = True
                inexistente.Visible = False
            Else
                datalistado.DataSource = Nothing
                txtbuscar.Enabled = False
                datalistado.ColumnHeadersVisible = False
                inexistente.Visible = True
            End If



        Catch ex As Exception

            MsgBox(ex.Message)
        End Try
        btnnuevo.Visible = True
        btneditar.Visible = False

        buscardnidocente()
    End Sub

    Private Sub buscardnidocente()
        Try
            Dim ds As New DataSet
            ds.Tables.Add(dt.Copy)
            Dim dv As New DataView(ds.Tables(0))

            dv.RowFilter = String.Format("Convert (dniDoc,'System.String')", cbocampo.Text) & " like '%" & txtbuscar.Text & "%'"

            If dv.Count <> 0 Then
                inexistente.Visible = False
                datalistado.DataSource = dv

            Else
                inexistente.Visible = True
                datalistado.DataSource = Nothing

            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub ocultar_columnas()
        datalistado.Columns(1).Visible = False
    End Sub



    Private Sub btnregistrar_Click(sender As Object, e As EventArgs) Handles btnregistrar.Click
        If Me.ValidateChildren = True And txtdni.Text <> "" And txtnombre.Text <> "" And txtapa.Text <> "" And txtama.Text <>
                     "" And txtedad.Text <> "" And ComboBox1.Text <> "" And txttelefono.Text <> "" And txtdireccion.Text <> "" And FnaDocDateTimePicker1.Text <> "" And txtcorreo.Text <> "" And ComboBox2.Text <> "" Then
            Try
                Dim dts As New vdocente
                Dim func As New fdocente

                dts.gdniDoc = txtdni.Text
                dts.gnomDoc = txtnombre.Text
                dts.gapaDoc = txtapa.Text
                dts.gamaDoc = txtama.Text
                dts.gedaDoc = txtedad.Text
                dts.gsexDoc = ComboBox1.Text
                dts.gtelDoc = txttelefono.Text
                dts.gdirDoc = txtdireccion.Text
                dts.gfnaDoc = FnaDocDateTimePicker1.Text
                dts.gemaDoc = txtcorreo.Text
                dts.gespDoc = ComboBox2.Text




                If func.insertardocente(dts) Then
                    MessageBox.Show("Docente registrado correctamente", "Guardando registros", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    MessageBox.Show("Seleccione su registro para definir horario", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    mostrardocente()
                    limpiar()
                Else
                    MessageBox.Show("Docente no fue registrado intente de nuevo ", "Guardando registros", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    mostrardocente()
                    limpiarduplicado()


                End If
            Catch ex As Exception

                MsgBox(ex.Message)
            End Try
        Else
            MessageBox.Show("Faltan ingresar datos ", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)

        End If
    End Sub

    Private Sub datalistado_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles datalistado.CellContentClick
        If e.ColumnIndex = Me.datalistado.Columns.Item("Eliminar").Index Then
            Dim chkcell As DataGridViewCheckBoxCell = Me.datalistado.Rows(e.RowIndex).Cells("Eliminar")
            chkcell.Value = Not chkcell.Value
        End If
    End Sub

    Private Sub btneliminar_Click(sender As Object, e As EventArgs) Handles btneliminar.Click
        Dim result As DialogResult
        result = MessageBox.Show("¿Realmente quiere eliminar a los docentes seleccionados?", "Eliminando registros ", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
        If result = DialogResult.OK Then
            Try
                For Each row As DataGridViewRow In datalistado.Rows
                    Dim marcado As Boolean = Convert.ToBoolean(row.Cells("Eliminar").Value)
                    If marcado Then
                        Dim onekey As Integer = Convert.ToInt32(row.Cells("dniDoc").Value)
                        Dim vdb As New vdocente
                        Dim func As New fdocente
                        vdb.gdniDoc = onekey

                        If func.eliminardocente(vdb) Then
                        Else
                            MessageBox.Show("Docente no eliminado", "Eliminando registros ", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        End If
                    End If

                Next
                Call mostrardocente()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Else
            MessageBox.Show("Cancelando eliminacion de registros", "Eliminando registros ", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Call mostrardocente()
        End If
        Call limpiar()
    End Sub

    Private Sub datalistado_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles datalistado.CellClick
        Dim I As String = e.RowIndex
        frmHorario.txtdnidoc.Text = datalistado.Rows(I).Cells(1).Value

        txtdni.Text = datalistado.SelectedCells.Item(1).Value
        txtnombre.Text = datalistado.SelectedCells.Item(2).Value
        txtapa.Text = datalistado.SelectedCells.Item(3).Value
        txtama.Text = datalistado.SelectedCells.Item(4).Value
        txtedad.Text = datalistado.SelectedCells.Item(5).Value
        ComboBox1.Text = datalistado.SelectedCells.Item(6).Value
        txttelefono.Text = datalistado.SelectedCells.Item(7).Value
        txtdireccion.Text = datalistado.SelectedCells.Item(8).Value
        FnaDocDateTimePicker1.Text = datalistado.SelectedCells.Item(9).Value
        txtcorreo.Text = datalistado.SelectedCells.Item(10).Value
        ComboBox2.Text = datalistado.SelectedCells.Item(11).Value
        If txtdni.Enabled = False Then
        Else
            txtdni.Enabled = False
        End If
        btneditar.Visible = True
        btnregistrar.Visible = False
    End Sub

    Private Sub btneditar_Click(sender As Object, e As EventArgs) Handles btneditar.Click
        Dim result As DialogResult
        result = MessageBox.Show("Realmente desea editar los datos del alumno", "Modificando registros ", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
        If result = DialogResult.OK Then

            If Me.ValidateChildren = True And txtdni.Text <> "" And txtnombre.Text <> "" And txtapa.Text <> "" And txtama.Text <>
                     "" And txtedad.Text <> "" And ComboBox1.Text <> "" And txttelefono.Text <> "" And txtdireccion.Text <> "" And FnaDocDateTimePicker1.Text <> "" And txtcorreo.Text <> "" And ComboBox2.Text <> "" Then
                Try
                    Dim dts As New vdocente
                    Dim func As New fdocente


                    dts.gdniDoc = txtdni.Text
                    dts.gnomDoc = txtnombre.Text
                    dts.gapaDoc = txtapa.Text
                    dts.gamaDoc = txtama.Text
                    dts.gedaDoc = txtedad.Text
                    dts.gsexDoc = ComboBox1.Text
                    dts.gtelDoc = txttelefono.Text
                    dts.gdirDoc = txtdireccion.Text
                    dts.gfnaDoc = FnaDocDateTimePicker1.Text
                    dts.gemaDoc = txtcorreo.Text
                    dts.gespDoc = ComboBox2.Text


                    If func.editardocente(dts) Then
                        MessageBox.Show("Docente modificado correctamente", "Modificando registros", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        mostrardocente()
                        limpiar()
                    Else
                        MessageBox.Show("Docente no fue modificado intente de nuevo ", "Modificando registros", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        mostrardocente()
                        limpiar()

                    End If
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try
            Else
                MessageBox.Show("Faltan ingresar datos ", "Guardando datos", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        End If

    End Sub

    Private Sub cbeliminar_CheckedChanged(sender As Object, e As EventArgs) Handles cbeliminar.CheckedChanged
        If cbeliminar.CheckState = CheckState.Checked Then
            datalistado.Columns.Item("Eliminar").Visible = True
        Else

            datalistado.Columns.Item("Eliminar").Visible = False
        End If
    End Sub

    Private Sub btnregresar_Click(sender As Object, e As EventArgs) Handles btnregresar.Click
        menuprincipal.Show()
        Me.Hide()
    End Sub

    Private Sub bntimprimir_Click(sender As Object, e As EventArgs) Handles bntimprimir.Click
        ReporteDocente.Show()
    End Sub

    Private Sub txtdni_TextChanged(sender As Object, e As EventArgs) Handles txtdni.TextChanged

    End Sub

    Private Sub txtdni_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtdni.KeyPress

        If (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End If

    End Sub

    Private Sub txttelefono_TextChanged(sender As Object, e As EventArgs) Handles txttelefono.TextChanged

    End Sub

    Private Sub txttelefono_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txttelefono.KeyPress

        If (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End If

    End Sub

    Private Sub txtnombre_TextChanged(sender As Object, e As EventArgs) Handles txtnombre.TextChanged

    End Sub

    Private Sub txtnombre_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtnombre.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If
    End Sub

    Private Sub txtapa_TextChanged(sender As Object, e As EventArgs) Handles txtapa.TextChanged

    End Sub

    Private Sub txtapa_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtapa.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If
    End Sub

    Private Sub txtama_TextChanged(sender As Object, e As EventArgs) Handles txtama.TextChanged

    End Sub

    Private Sub txtama_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtama.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If
    End Sub

    Private Sub FnaDocDateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles FnaDocDateTimePicker1.ValueChanged
        Dim FECHANAC As Date
        Dim EDAD As Integer
        FECHANAC = FnaDocDateTimePicker1.Value
        EDAD = Now.Year - FECHANAC.Year
        txtedad.Text = CStr(EDAD)
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        frmHorario.ShowDialog()

    End Sub

    Private Sub btnnuevo_Click(sender As Object, e As EventArgs) Handles btnnuevo.Click
        Me.Width = 900
        limpiar()
        txtdni.Focus()
        mostrardocente()

        If txtdni.Enabled = True Then
        Else
            txtdni.Enabled = True
        End If
    End Sub

    Private Sub txtdni_Validated(sender As Object, e As EventArgs) Handles txtdni.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
        'solo acepte 8 digitos si es menos sale el mensaje
        If Len(txtdni.Text) < 8 Then
            btnregistrar.Visible = False
            MessageBox.Show("Faltan digitos al DNI", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            btnregistrar.Visible = True
        End If
    End Sub

    Private Sub txtnombre_Validated(sender As Object, e As EventArgs) Handles txtnombre.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
        If Len(txtnombre.Text) < 2 Then
            btnregistrar.Visible = False
            MessageBox.Show("Insertar mas  2 caracteres ", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            btnregistrar.Visible = True
        End If
    End Sub

    Private Sub txtapa_Validated(sender As Object, e As EventArgs) Handles txtapa.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
        If Len(txtapa.Text) < 2 Then
            btnregistrar.Visible = False
            MessageBox.Show("Insertar mas  2 caracteres ", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            btnregistrar.Visible = True
        End If
    End Sub

    Private Sub txtama_Validated(sender As Object, e As EventArgs) Handles txtama.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
        If Len(txtama.Text) < 2 Then
            btnregistrar.Visible = False
            MessageBox.Show("Insertar mas  2 caracteres ", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            btnregistrar.Visible = True
        End If
    End Sub



    Private Sub txttelefono_Validated(sender As Object, e As EventArgs) Handles txttelefono.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
        If Len(txttelefono.Text) < 9 Then
            btnregistrar.Visible = False
            MessageBox.Show("Faltan digitos", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            btnregistrar.Visible = True
        End If

    End Sub

    Private Sub txtdireccion_Validated(sender As Object, e As EventArgs) Handles txtdireccion.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
        If Len(txtdireccion.Text) < 2 Then
            btnregistrar.Visible = False
            MessageBox.Show("Insertar mas  2 caracteres ", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            btnregistrar.Visible = True
        End If
    End Sub

    Private Sub txtcorreo_Validated(sender As Object, e As EventArgs) Handles txtcorreo.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
    End Sub

    Private Sub ComboBox2_Validated(sender As Object, e As EventArgs) Handles ComboBox2.Validated
        If DirectCast(sender, ComboBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
    End Sub

    Private Sub ComboBox1_Validated(sender As Object, e As EventArgs) Handles ComboBox1.Validated
        If DirectCast(sender, ComboBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
    End Sub

    Private Sub FnaDocDateTimePicker1_Validated(sender As Object, e As EventArgs) Handles FnaDocDateTimePicker1.Validated
        If DirectCast(sender, DateTimePicker).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
    End Sub

    Private Sub txtbuscar_TextChanged(sender As Object, e As EventArgs) Handles txtbuscar.TextChanged
        buscardnidocente()
    End Sub




    Private Function validar_Mail(ByVal sMail As String) As Boolean
        ' retorna true o false   
        Return Regex.IsMatch(sMail,
         "^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$")
    End Function

    Private Sub txtcorreo_Leave(sender As Object, e As EventArgs) Handles txtcorreo.Leave
        If validar_Mail(LCase(txtcorreo.Text)) = False Then
            MessageBox.Show("Dirección de correo electronico no valida,el correo debe tener el formato: nombre@ejemplo.com, " & "por favor seleccione un correo valido", "Validación de correo electronico", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            txtcorreo.Focus()
            txtcorreo.SelectAll()

        End If

    End Sub


    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            btnregistrar.Enabled = True

            txtdni.Enabled = True
            txtnombre.Enabled = True
            txtapa.Enabled = True
            txtama.Enabled = True
            FnaDocDateTimePicker1.Enabled = True
            txtapa.Enabled = True
            ComboBox1.Enabled = True
            txtdireccion.Enabled = True
            txttelefono.Enabled = True
            ComboBox2.Enabled = True
            txtcorreo.Enabled = True
            txtdni.Focus()
        Else
            txtdni.Enabled = False
            txtnombre.Enabled = False
            txtapa.Enabled = False
            txtama.Enabled = False
            FnaDocDateTimePicker1.Enabled = False
            txtapa.Enabled = False
            ComboBox1.Enabled = False
            txtdireccion.Enabled = False
            txttelefono.Enabled = False
            ComboBox2.Enabled = False
            txtcorreo.Enabled = False
            btnregistrar.Enabled = False
        End If
    End Sub

    Private Sub Label12_Click(sender As Object, e As EventArgs) Handles Label12.Click
        If Label12.Visible = True Then
        ElseIf Label12.Visible = False Then
        End If
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged

    End Sub

    Private Sub ComboBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ComboBox2.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        End If
    End Sub

    Private Sub ComboBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ComboBox1.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        End If
    End Sub

    'Private Sub frmdocente(sender As Object, e As System.EventArgs) Handles Me.Load
    'Me.MaskedTextBox1.Mask = "999-999-999"
    'Me.MaskedTextBox1.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals
    'End Sub

    'Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
    'If Me.MaskedTextBox1.Text.Length > 0 And Me.MaskedTextBox1.Text.Length < 9 Then
    '   MessageBox.Show("Incorrecto")
    'Else
    '    MessageBox.Show("Correcto")
    'End If
    'End Sub
End Class







