﻿Public Class menuprincipal
    Private Sub Label6_Click(sender As Object, e As EventArgs)
    End Sub

    Private Sub btnmatricula_Click(sender As Object, e As EventArgs) Handles btnmatricula.Click
        frmmatricula.ShowDialog()

    End Sub

    Private Sub menuprincipal_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnalumno_Click(sender As Object, e As EventArgs) Handles btnalumno.Click
        frmalumno.ShowDialog()

    End Sub

    Private Sub btndocente_Click(sender As Object, e As EventArgs) Handles btndocente.Click
        frmdocente.ShowDialog()

    End Sub

    Private Sub btnaula_Click(sender As Object, e As EventArgs) Handles btnaula.Click
        frmaula.ShowDialog()

    End Sub

    Private Sub btnapoderado_Click(sender As Object, e As EventArgs) Handles btnapoderado.Click
        frmapoderado.ShowDialog()

    End Sub



    Private Sub label2_Click(sender As Object, e As EventArgs) Handles label2.Click

    End Sub

    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs) Handles GroupBox2.Enter

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        lblhora.Text = Now.ToLongTimeString() 'Hora en formato largo
        lblfecha.Text = Now.ToShortDateString() 'fecha en formato corto
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.WindowState = 1
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim confirma = MsgBox("Está seguro que Desea Salir?", vbYesNo + vbExclamation, "Atención!!")
        If confirma = vbYes Then
            Me.Close()
            Login.Close()
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        frmañoescolar.ShowDialog()
    End Sub
End Class