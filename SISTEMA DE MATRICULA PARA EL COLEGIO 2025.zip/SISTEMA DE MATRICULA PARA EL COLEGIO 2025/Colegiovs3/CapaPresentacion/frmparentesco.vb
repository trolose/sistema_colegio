﻿Imports System.Data.SqlClient
Imports System.Data
Imports CapaDatos
Imports CapaEntidad
Public Class frmparentesco
    Private dt As New DataTable
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        frmapoderado.Show()
        Me.Hide()
    End Sub

    Private Sub frmparentesco_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        mostrarparentesco()
    End Sub
    Private Sub mostrarparentesco()
        Try
            Dim func As New fparentesco
            dt = func.mostrarparentesco
            datalistado.Columns.Item("Eliminar").Visible = False


            If dt.Rows.Count <> 0 Then
                datalistado.DataSource = dt

                datalistado.ColumnHeadersVisible = True
                inexistente.Visible = False
            Else
                datalistado.DataSource = Nothing

                datalistado.ColumnHeadersVisible = False
                inexistente.Visible = True

            End If
        Catch ex As Exception

            MsgBox(ex.Message)
        End Try
    End Sub



    Private Sub btnregistrar_Click(sender As Object, e As EventArgs) Handles btnregistrar.Click
        If Me.ValidateChildren = True And cbparentesco.Text <> "" And txtdnialu.Text <> "" And txtdniapo.Text <> "" Then
            Try
                Dim dts As New vparentesco
                Dim func As New fparentesco

                'dts.gcodPar = txtcodigo.Text
                dts.gparPar = cbparentesco.Text
                dts.gdniAlu = txtdnialu.Text
                dts.gdniApo = txtdniapo.Text

                If func.insertarparentesco(dts) Then
                    MessageBox.Show("Parentesco registrado correctamente", "Guardando registros", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    mostrarparentesco()

                Else
                    MessageBox.Show("Parentesco no fue registrado intente de nuevo ", "Guardando registros", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    mostrarparentesco()
                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Else
            MessageBox.Show("Faltan ingresar datos ", "Guardando datos", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If



    End Sub



    Private Sub datalistado_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles datalistado.CellContentClick
        If e.ColumnIndex = Me.datalistado.Columns.Item("Eliminar").Index Then
            Dim chkcell As DataGridViewCheckBoxCell = Me.datalistado.Rows(e.RowIndex).Cells("Eliminar")
            chkcell.Value = Not chkcell.Value
        End If
    End Sub

    Private Sub datalistado_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles datalistado.CellClick

        txtcodigo.Text = datalistado.SelectedCells.Item(1).Value
        cbparentesco.Text = datalistado.SelectedCells.Item(2).Value
        txtdnialu.Text = datalistado.SelectedCells.Item(3).Value
        txtdniapo.Text = datalistado.SelectedCells.Item(4).Value
        btnregistrar.Visible = True
    End Sub

    Private Sub cbeliminar_CheckedChanged(sender As Object, e As EventArgs) Handles cbeliminar.CheckedChanged
        If cbeliminar.CheckState = CheckState.Checked Then
            datalistado.Columns.Item("Eliminar").Visible = True
        Else

            datalistado.Columns.Item("Eliminar").Visible = False
        End If
    End Sub

    Private Sub btneliminar_Click(sender As Object, e As EventArgs) Handles btneliminar.Click
        Dim result As DialogResult
        result = MessageBox.Show("¿Realmente quiere eliminar los elementos seleccionados?", "Eliminando registros ", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
        If result = DialogResult.OK Then
            Try
                For Each row As DataGridViewRow In datalistado.Rows
                    Dim marcado As Boolean = Convert.ToBoolean(row.Cells("Eliminar").Value)
                    If marcado Then
                        Dim onekey As Integer = Convert.ToInt32(row.Cells("codPar").Value)
                        Dim vdb As New vparentesco
                        Dim func As New fparentesco
                        vdb.gcodPar = onekey

                        If func.eliminarparentesco(vdb) Then
                        Else
                            MessageBox.Show(" No eliminado", "Eliminando registros ", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        End If
                    End If

                Next
                Call mostrarparentesco()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Else
            MessageBox.Show("Cancelando eliminacion de registros", "Eliminando registros ", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Call mostrarparentesco()
        End If
        Call limpiar()
    End Sub
    Public Sub limpiar()
        btnregistrar.Visible = True
        'txtcodigo.Text = ""
        cbparentesco.Text = ""

    End Sub

    Private Sub CheckBox1_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            btnregistrar.Enabled = True

            cbparentesco.Enabled = True
            txtdnialu.Enabled = True
            txtdniapo.Enabled = True
            cbparentesco.Focus()
        Else
            cbparentesco.Enabled = False
            txtdnialu.Enabled = False
            txtdniapo.Enabled = False
            btnregistrar.Enabled = False
        End If
    End Sub

    Private Sub cbparentesco_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cbparentesco.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtdnialu_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtdnialu.KeyPress
        If (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True

        End If

    End Sub

    Private Sub txtdniapo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtdniapo.KeyPress
        If (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True

        End If
    End Sub



    Private Sub btnuevo_Click(sender As Object, e As EventArgs) Handles btnuevo.Click
        limpiar()
    End Sub

    Private Sub cbparentesco_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbparentesco.SelectedIndexChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ReporteParentesco.Show()
    End Sub
End Class