﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class menuprincipal
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnapoderado = New System.Windows.Forms.Button()
        Me.btnaula = New System.Windows.Forms.Button()
        Me.btndocente = New System.Windows.Forms.Button()
        Me.btnalumno = New System.Windows.Forms.Button()
        Me.btnmatricula = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.label2 = New System.Windows.Forms.Label()
        Me.lblhora = New System.Windows.Forms.Label()
        Me.lblfecha = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.BackgroundImage = Global.CapaPresentacion.My.Resources.Resources.fondooo
        Me.GroupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.btnapoderado)
        Me.GroupBox1.Controls.Add(Me.btnaula)
        Me.GroupBox1.Controls.Add(Me.btndocente)
        Me.GroupBox1.Controls.Add(Me.btnalumno)
        Me.GroupBox1.Controls.Add(Me.btnmatricula)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Location = New System.Drawing.Point(292, 174)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(750, 442)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'btnapoderado
        '
        Me.btnapoderado.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.btnapoderado.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnapoderado.Font = New System.Drawing.Font("Cooper Black", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnapoderado.Location = New System.Drawing.Point(59, 193)
        Me.btnapoderado.Name = "btnapoderado"
        Me.btnapoderado.Size = New System.Drawing.Size(161, 60)
        Me.btnapoderado.TabIndex = 10
        Me.btnapoderado.Text = "Apoderado"
        Me.btnapoderado.UseVisualStyleBackColor = False
        '
        'btnaula
        '
        Me.btnaula.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.btnaula.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnaula.Font = New System.Drawing.Font("Cooper Black", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnaula.Location = New System.Drawing.Point(178, 314)
        Me.btnaula.Name = "btnaula"
        Me.btnaula.Size = New System.Drawing.Size(173, 67)
        Me.btnaula.TabIndex = 9
        Me.btnaula.Text = "Aula"
        Me.btnaula.UseVisualStyleBackColor = False
        '
        'btndocente
        '
        Me.btndocente.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.btndocente.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btndocente.Font = New System.Drawing.Font("Cooper Black", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndocente.Location = New System.Drawing.Point(410, 314)
        Me.btndocente.Name = "btndocente"
        Me.btndocente.Size = New System.Drawing.Size(167, 67)
        Me.btndocente.TabIndex = 8
        Me.btndocente.Text = "Docente"
        Me.btndocente.UseVisualStyleBackColor = False
        '
        'btnalumno
        '
        Me.btnalumno.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.btnalumno.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnalumno.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnalumno.Font = New System.Drawing.Font("Cooper Black", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnalumno.Location = New System.Drawing.Point(420, 61)
        Me.btnalumno.Name = "btnalumno"
        Me.btnalumno.Size = New System.Drawing.Size(168, 63)
        Me.btnalumno.TabIndex = 7
        Me.btnalumno.Text = "Registrar alumno"
        Me.btnalumno.UseVisualStyleBackColor = False
        '
        'btnmatricula
        '
        Me.btnmatricula.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.btnmatricula.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnmatricula.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnmatricula.Font = New System.Drawing.Font("Cooper Black", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnmatricula.Location = New System.Drawing.Point(178, 61)
        Me.btnmatricula.Name = "btnmatricula"
        Me.btnmatricula.Size = New System.Drawing.Size(155, 63)
        Me.btnmatricula.TabIndex = 6
        Me.btnmatricula.Text = "Iniciar matricula"
        Me.btnmatricula.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(417, 224)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(39, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Label3"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.label2)
        Me.GroupBox2.Controls.Add(Me.lblhora)
        Me.GroupBox2.Controls.Add(Me.lblfecha)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.GroupBox2.Location = New System.Drawing.Point(36, 647)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(302, 90)
        Me.GroupBox2.TabIndex = 26
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Fecha y Hora"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.ForeColor = System.Drawing.SystemColors.Control
        Me.label2.Location = New System.Drawing.Point(5, 26)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(75, 24)
        Me.label2.TabIndex = 20
        Me.label2.Text = "Fecha:"
        '
        'lblhora
        '
        Me.lblhora.BackColor = System.Drawing.Color.Transparent
        Me.lblhora.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhora.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblhora.Location = New System.Drawing.Point(86, 52)
        Me.lblhora.Name = "lblhora"
        Me.lblhora.Size = New System.Drawing.Size(116, 21)
        Me.lblhora.TabIndex = 23
        Me.lblhora.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblfecha
        '
        Me.lblfecha.BackColor = System.Drawing.Color.Transparent
        Me.lblfecha.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Bold)
        Me.lblfecha.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblfecha.Location = New System.Drawing.Point(86, 30)
        Me.lblfecha.Name = "lblfecha"
        Me.lblfecha.Size = New System.Drawing.Size(150, 19)
        Me.lblfecha.TabIndex = 21
        Me.lblfecha.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.Control
        Me.Label4.Location = New System.Drawing.Point(5, 52)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(61, 24)
        Me.Label4.TabIndex = 22
        Me.Label4.Text = "Hora:"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Panel1.Location = New System.Drawing.Point(-13, -2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1387, 90)
        Me.Panel1.TabIndex = 27
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Maroon
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button2.Location = New System.Drawing.Point(1327, 6)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(38, 38)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "X"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Maroon
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button1.Location = New System.Drawing.Point(1281, 6)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(40, 38)
        Me.Button1.TabIndex = 17
        Me.Button1.Text = "-"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.PictureBox1.Image = Global.CapaPresentacion.My.Resources.Resources.g_gif_update1
        Me.PictureBox1.Location = New System.Drawing.Point(233, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(802, 87)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button3.Font = New System.Drawing.Font("Cooper Black", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(534, 190)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(168, 63)
        Me.Button3.TabIndex = 11
        Me.Button3.Text = "Año escolar"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'menuprincipal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.BackgroundImage = Global.CapaPresentacion.My.Resources.Resources.fondo_bg
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1386, 788)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "menuprincipal"
        Me.Text = "menuprincipal"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label3 As Label
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents btnmatricula As Button
    Friend WithEvents btnalumno As Button
    Friend WithEvents btnapoderado As Button
    Friend WithEvents btnaula As Button
    Friend WithEvents btndocente As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents label2 As Label
    Friend WithEvents lblhora As Label
    Friend WithEvents lblfecha As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Panel1 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Button3 As Button
End Class
