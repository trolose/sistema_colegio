﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmHorario
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ColegioBDDataSet = New CapaPresentacion.ColegioBDDataSet()
        Me.HorarioBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.HorarioTableAdapter = New CapaPresentacion.ColegioBDDataSetTableAdapters.HorarioTableAdapter()
        Me.TableAdapterManager = New CapaPresentacion.ColegioBDDataSetTableAdapters.TableAdapterManager()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txthorario = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.cbcurso = New System.Windows.Forms.ComboBox()
        Me.cbaula = New System.Windows.Forms.ComboBox()
        Me.cbdia = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtdnidoc = New System.Windows.Forms.TextBox()
        Me.txtseccion = New System.Windows.Forms.TextBox()
        Me.txtfin = New System.Windows.Forms.TextBox()
        Me.txtinicio = New System.Windows.Forms.TextBox()
        Me.btnregistrar = New System.Windows.Forms.Button()
        Me.btnsalir = New System.Windows.Forms.Button()
        Me.CursoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.inexistente = New System.Windows.Forms.LinkLabel()
        Me.datalistado = New System.Windows.Forms.DataGridView()
        Me.Eliminar = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.cbeliminar = New System.Windows.Forms.CheckBox()
        Me.cbcampo = New System.Windows.Forms.ComboBox()
        Me.txtbuscar = New System.Windows.Forms.TextBox()
        Me.HorarioBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.ULTIMO = New CapaPresentacion.uLTIMO()
        Me.CursoTableAdapter = New CapaPresentacion.ColegioBDDataSetTableAdapters.CursoTableAdapter()
        Me.HorarioTableAdapter1 = New CapaPresentacion.uLTIMOTableAdapters.HorarioTableAdapter()
        Me.TableAdapterManager1 = New CapaPresentacion.uLTIMOTableAdapters.TableAdapterManager()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.editar = New System.Windows.Forms.Button()
        Me.btneliminar = New System.Windows.Forms.Button()
        Me.btnnuevo = New System.Windows.Forms.Button()
        Me.inicio = New System.Windows.Forms.CheckBox()
        Me.ULTIMO1 = New CapaPresentacion.uLTIMO()
        Me.erroricon = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnimprimir = New System.Windows.Forms.Button()
        CType(Me.ColegioBDDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HorarioBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.CursoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.datalistado, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HorarioBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ULTIMO, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.ULTIMO1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.erroricon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ColegioBDDataSet
        '
        Me.ColegioBDDataSet.DataSetName = "ColegioBDDataSet"
        Me.ColegioBDDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'HorarioBindingSource
        '
        Me.HorarioBindingSource.DataMember = "Horario"
        Me.HorarioBindingSource.DataSource = Me.ColegioBDDataSet
        '
        'HorarioTableAdapter
        '
        Me.HorarioTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AlumnoTableAdapter = Nothing
        Me.TableAdapterManager.Año_EscolarTableAdapter = Nothing
        Me.TableAdapterManager.ApoderadoTableAdapter = Nothing
        Me.TableAdapterManager.AulaTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CursoTableAdapter = Nothing
        Me.TableAdapterManager.DocenteTableAdapter = Nothing
        Me.TableAdapterManager.EspecialidadTableAdapter = Nothing
        Me.TableAdapterManager.HorarioTableAdapter = Me.HorarioTableAdapter
        Me.TableAdapterManager.MatriculaTableAdapter = Nothing
        Me.TableAdapterManager.NotaTableAdapter = Nothing
        Me.TableAdapterManager.ParentescoTableAdapter = Nothing
        Me.TableAdapterManager.PersonaTableAdapter = Nothing
        Me.TableAdapterManager.tipousuarioTableAdapter = Nothing
        Me.TableAdapterManager.TrimestreTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = CapaPresentacion.ColegioBDDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.usuarioTableAdapter = Nothing
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.txthorario)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.cbcurso)
        Me.GroupBox1.Controls.Add(Me.cbaula)
        Me.GroupBox1.Controls.Add(Me.cbdia)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtdnidoc)
        Me.GroupBox1.Controls.Add(Me.txtseccion)
        Me.GroupBox1.Controls.Add(Me.txtfin)
        Me.GroupBox1.Controls.Add(Me.txtinicio)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 41)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(504, 163)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Horario de clases "
        '
        'txthorario
        '
        Me.txthorario.Location = New System.Drawing.Point(98, 13)
        Me.txthorario.Name = "txthorario"
        Me.txthorario.Size = New System.Drawing.Size(100, 20)
        Me.txthorario.TabIndex = 22
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(12, 16)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(80, 13)
        Me.Label9.TabIndex = 21
        Me.Label9.Text = "Codigo Horario "
        '
        'cbcurso
        '
        Me.cbcurso.Cursor = System.Windows.Forms.Cursors.Default
        Me.cbcurso.Enabled = False
        Me.cbcurso.FormattingEnabled = True
        Me.cbcurso.Items.AddRange(New Object() {"MAT01 ", "CTA01 ", "COM01 ", "PFR01 ", "EF001", "EA001", "ET001 ", "R0001 ", "I0001 "})
        Me.cbcurso.Location = New System.Drawing.Point(296, 120)
        Me.cbcurso.Name = "cbcurso"
        Me.cbcurso.Size = New System.Drawing.Size(200, 21)
        Me.cbcurso.TabIndex = 20
        '
        'cbaula
        '
        Me.cbaula.Enabled = False
        Me.cbaula.FormattingEnabled = True
        Me.cbaula.Items.AddRange(New Object() {"Seleccione", "1", "2", "3", "4", "5", "6"})
        Me.cbaula.Location = New System.Drawing.Point(144, 120)
        Me.cbaula.Name = "cbaula"
        Me.cbaula.Size = New System.Drawing.Size(121, 21)
        Me.cbaula.TabIndex = 2
        '
        'cbdia
        '
        Me.cbdia.Enabled = False
        Me.cbdia.FormattingEnabled = True
        Me.cbdia.Items.AddRange(New Object() {"Seleccione", "Lunes", "Martes", "Miercoles", "Jueves", "Viernes"})
        Me.cbdia.Location = New System.Drawing.Point(144, 50)
        Me.cbdia.Name = "cbdia"
        Me.cbdia.Size = New System.Drawing.Size(121, 21)
        Me.cbdia.TabIndex = 16
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(307, 102)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(34, 13)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "Curso"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(21, 35)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(65, 13)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Dni docente"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(162, 102)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(28, 13)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Aula"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(23, 102)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(46, 13)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Seccion"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(393, 35)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(62, 13)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Hora de fin "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(278, 35)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 13)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Hora de inicio"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(162, 35)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(26, 13)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Dia "
        '
        'txtdnidoc
        '
        Me.txtdnidoc.Enabled = False
        Me.txtdnidoc.Location = New System.Drawing.Point(24, 51)
        Me.txtdnidoc.MaxLength = 8
        Me.txtdnidoc.Name = "txtdnidoc"
        Me.txtdnidoc.Size = New System.Drawing.Size(100, 20)
        Me.txtdnidoc.TabIndex = 6
        '
        'txtseccion
        '
        Me.txtseccion.BackColor = System.Drawing.SystemColors.Control
        Me.txtseccion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtseccion.Enabled = False
        Me.txtseccion.Location = New System.Drawing.Point(26, 117)
        Me.txtseccion.Name = "txtseccion"
        Me.txtseccion.Size = New System.Drawing.Size(58, 20)
        Me.txtseccion.TabIndex = 4
        '
        'txtfin
        '
        Me.txtfin.Enabled = False
        Me.txtfin.Location = New System.Drawing.Point(396, 51)
        Me.txtfin.Name = "txtfin"
        Me.txtfin.Size = New System.Drawing.Size(100, 20)
        Me.txtfin.TabIndex = 3
        '
        'txtinicio
        '
        Me.txtinicio.Enabled = False
        Me.txtinicio.Location = New System.Drawing.Point(281, 51)
        Me.txtinicio.Name = "txtinicio"
        Me.txtinicio.Size = New System.Drawing.Size(100, 20)
        Me.txtinicio.TabIndex = 2
        '
        'btnregistrar
        '
        Me.btnregistrar.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.btnregistrar.Location = New System.Drawing.Point(6, 54)
        Me.btnregistrar.Name = "btnregistrar"
        Me.btnregistrar.Size = New System.Drawing.Size(75, 23)
        Me.btnregistrar.TabIndex = 19
        Me.btnregistrar.Text = "Registrar"
        Me.btnregistrar.UseVisualStyleBackColor = False
        '
        'btnsalir
        '
        Me.btnsalir.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.btnsalir.Location = New System.Drawing.Point(6, 3)
        Me.btnsalir.Name = "btnsalir"
        Me.btnsalir.Size = New System.Drawing.Size(75, 23)
        Me.btnsalir.TabIndex = 17
        Me.btnsalir.Text = "Regresar"
        Me.btnsalir.UseVisualStyleBackColor = False
        '
        'CursoBindingSource
        '
        Me.CursoBindingSource.DataMember = "Curso"
        Me.CursoBindingSource.DataSource = Me.ColegioBDDataSet
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.inexistente)
        Me.GroupBox2.Controls.Add(Me.datalistado)
        Me.GroupBox2.Controls.Add(Me.cbeliminar)
        Me.GroupBox2.Controls.Add(Me.cbcampo)
        Me.GroupBox2.Controls.Add(Me.txtbuscar)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 219)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(562, 272)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Listado"
        '
        'inexistente
        '
        Me.inexistente.AutoSize = True
        Me.inexistente.Location = New System.Drawing.Point(278, 161)
        Me.inexistente.Name = "inexistente"
        Me.inexistente.Size = New System.Drawing.Size(93, 13)
        Me.inexistente.TabIndex = 10
        Me.inexistente.TabStop = True
        Me.inexistente.Text = "Datos inexistentes"
        '
        'datalistado
        '
        Me.datalistado.AllowUserToAddRows = False
        Me.datalistado.AllowUserToDeleteRows = False
        Me.datalistado.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.datalistado.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Eliminar})
        Me.datalistado.Location = New System.Drawing.Point(15, 78)
        Me.datalistado.Name = "datalistado"
        Me.datalistado.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.datalistado.Size = New System.Drawing.Size(516, 172)
        Me.datalistado.TabIndex = 13
        '
        'Eliminar
        '
        Me.Eliminar.HeaderText = "Eliminar"
        Me.Eliminar.Name = "Eliminar"
        '
        'cbeliminar
        '
        Me.cbeliminar.AutoSize = True
        Me.cbeliminar.Location = New System.Drawing.Point(15, 55)
        Me.cbeliminar.Name = "cbeliminar"
        Me.cbeliminar.Size = New System.Drawing.Size(62, 17)
        Me.cbeliminar.TabIndex = 12
        Me.cbeliminar.Text = "Eliminar"
        Me.cbeliminar.UseVisualStyleBackColor = True
        '
        'cbcampo
        '
        Me.cbcampo.AutoCompleteCustomSource.AddRange(New String() {"dniAlu"})
        Me.cbcampo.FormattingEnabled = True
        Me.cbcampo.Items.AddRange(New Object() {"Dni"})
        Me.cbcampo.Location = New System.Drawing.Point(15, 19)
        Me.cbcampo.Name = "cbcampo"
        Me.cbcampo.Size = New System.Drawing.Size(121, 21)
        Me.cbcampo.TabIndex = 9
        Me.cbcampo.Text = "Seleccione"
        '
        'txtbuscar
        '
        Me.txtbuscar.Location = New System.Drawing.Point(176, 19)
        Me.txtbuscar.Name = "txtbuscar"
        Me.txtbuscar.Size = New System.Drawing.Size(293, 20)
        Me.txtbuscar.TabIndex = 8
        '
        'HorarioBindingSource1
        '
        Me.HorarioBindingSource1.DataMember = "Horario"
        Me.HorarioBindingSource1.DataSource = Me.ULTIMO
        '
        'ULTIMO
        '
        Me.ULTIMO.DataSetName = "uLTIMO"
        Me.ULTIMO.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'CursoTableAdapter
        '
        Me.CursoTableAdapter.ClearBeforeFill = True
        '
        'HorarioTableAdapter1
        '
        Me.HorarioTableAdapter1.ClearBeforeFill = True
        '
        'TableAdapterManager1
        '
        Me.TableAdapterManager1.AlumnoTableAdapter = Nothing
        Me.TableAdapterManager1.Año_EscolarTableAdapter = Nothing
        Me.TableAdapterManager1.ApoderadoTableAdapter = Nothing
        Me.TableAdapterManager1.AulaTableAdapter = Nothing
        Me.TableAdapterManager1.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager1.CursoTableAdapter = Nothing
        Me.TableAdapterManager1.DocenteTableAdapter = Nothing
        Me.TableAdapterManager1.HorarioTableAdapter = Me.HorarioTableAdapter1
        Me.TableAdapterManager1.MatriculaTableAdapter = Nothing
        Me.TableAdapterManager1.NotaTableAdapter = Nothing
        Me.TableAdapterManager1.ParentescoTableAdapter = Nothing
        Me.TableAdapterManager1.tipousuarioTableAdapter = Nothing
        Me.TableAdapterManager1.TRIMESTRESTableAdapter = Nothing
        Me.TableAdapterManager1.TrimestreTableAdapter = Nothing
        Me.TableAdapterManager1.UpdateOrder = CapaPresentacion.uLTIMOTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager1.usuarioTableAdapter = Nothing
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.LightGray
        Me.GroupBox3.Controls.Add(Me.editar)
        Me.GroupBox3.Controls.Add(Me.btneliminar)
        Me.GroupBox3.Controls.Add(Me.btnnuevo)
        Me.GroupBox3.Controls.Add(Me.inicio)
        Me.GroupBox3.Controls.Add(Me.btnregistrar)
        Me.GroupBox3.Location = New System.Drawing.Point(522, 41)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(92, 172)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Realizar"
        '
        'editar
        '
        Me.editar.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.editar.Location = New System.Drawing.Point(6, 140)
        Me.editar.Name = "editar"
        Me.editar.Size = New System.Drawing.Size(75, 23)
        Me.editar.TabIndex = 23
        Me.editar.Text = "Editar"
        Me.editar.UseVisualStyleBackColor = False
        '
        'btneliminar
        '
        Me.btneliminar.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.btneliminar.Location = New System.Drawing.Point(6, 86)
        Me.btneliminar.Name = "btneliminar"
        Me.btneliminar.Size = New System.Drawing.Size(75, 23)
        Me.btneliminar.TabIndex = 22
        Me.btneliminar.Text = "Eliminar"
        Me.btneliminar.UseVisualStyleBackColor = False
        '
        'btnnuevo
        '
        Me.btnnuevo.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.btnnuevo.Location = New System.Drawing.Point(6, 114)
        Me.btnnuevo.Name = "btnnuevo"
        Me.btnnuevo.Size = New System.Drawing.Size(75, 23)
        Me.btnnuevo.TabIndex = 21
        Me.btnnuevo.Text = "Nuevo"
        Me.btnnuevo.UseVisualStyleBackColor = False
        '
        'inicio
        '
        Me.inicio.AutoSize = True
        Me.inicio.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.inicio.Location = New System.Drawing.Point(6, 31)
        Me.inicio.Name = "inicio"
        Me.inicio.Size = New System.Drawing.Size(54, 17)
        Me.inicio.TabIndex = 20
        Me.inicio.Text = "Iniciar"
        Me.inicio.UseVisualStyleBackColor = False
        '
        'ULTIMO1
        '
        Me.ULTIMO1.DataSetName = "uLTIMO"
        Me.ULTIMO1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'erroricon
        '
        Me.erroricon.ContainerControl = Me
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Arial Rounded MT Bold", 15.75!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Red
        Me.Label1.Location = New System.Drawing.Point(212, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(208, 24)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Horario de Docente"
        '
        'btnimprimir
        '
        Me.btnimprimir.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.btnimprimir.Location = New System.Drawing.Point(14, 496)
        Me.btnimprimir.Name = "btnimprimir"
        Me.btnimprimir.Size = New System.Drawing.Size(75, 23)
        Me.btnimprimir.TabIndex = 20
        Me.btnimprimir.Text = "Reporte"
        Me.btnimprimir.UseVisualStyleBackColor = False
        '
        'frmHorario
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.CapaPresentacion.My.Resources.Resources.Degradado21
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(621, 531)
        Me.Controls.Add(Me.btnimprimir)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.btnsalir)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmHorario"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmHorario"
        CType(Me.ColegioBDDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HorarioBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.CursoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.datalistado, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HorarioBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ULTIMO, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.ULTIMO1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.erroricon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ColegioBDDataSet As ColegioBDDataSet
    Friend WithEvents HorarioBindingSource As BindingSource
    Friend WithEvents HorarioTableAdapter As ColegioBDDataSetTableAdapters.HorarioTableAdapter
    Friend WithEvents TableAdapterManager As ColegioBDDataSetTableAdapters.TableAdapterManager
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnregistrar As Button
    Friend WithEvents btnsalir As Button
    Friend WithEvents cbaula As ComboBox
    Friend WithEvents cbdia As ComboBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtdnidoc As TextBox
    Friend WithEvents txtseccion As TextBox
    Friend WithEvents txtfin As TextBox
    Friend WithEvents txtinicio As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents inexistente As LinkLabel
    Friend WithEvents cbcampo As ComboBox
    Friend WithEvents txtbuscar As TextBox
    Friend WithEvents cbcurso As ComboBox
    Friend WithEvents CursoBindingSource As BindingSource
    Friend WithEvents CursoTableAdapter As ColegioBDDataSetTableAdapters.CursoTableAdapter
    Friend WithEvents ULTIMO As uLTIMO
    Friend WithEvents HorarioBindingSource1 As BindingSource
    Friend WithEvents HorarioTableAdapter1 As uLTIMOTableAdapters.HorarioTableAdapter
    Friend WithEvents TableAdapterManager1 As uLTIMOTableAdapters.TableAdapterManager
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents inicio As CheckBox
    Friend WithEvents ULTIMO1 As uLTIMO
    Friend WithEvents erroricon As ErrorProvider
    Friend WithEvents btnnuevo As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents editar As Button
    Friend WithEvents btneliminar As Button
    Friend WithEvents cbeliminar As CheckBox
    Friend WithEvents datalistado As DataGridView
    Friend WithEvents Eliminar As DataGridViewCheckBoxColumn
    Friend WithEvents txthorario As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents btnimprimir As Button
End Class
