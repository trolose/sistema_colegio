﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ReporteDocente
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ReportDataSource1 As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource()
        Me.DocenteBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ColegioBDDataSet2 = New CapaPresentacion.ColegioBDDataSet2()
        Me.ReportViewer1 = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.DocenteTableAdapter = New CapaPresentacion.ColegioBDDataSet2TableAdapters.DocenteTableAdapter()
        CType(Me.DocenteBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColegioBDDataSet2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DocenteBindingSource
        '
        Me.DocenteBindingSource.DataMember = "Docente"
        Me.DocenteBindingSource.DataSource = Me.ColegioBDDataSet2
        '
        'ColegioBDDataSet2
        '
        Me.ColegioBDDataSet2.DataSetName = "ColegioBDDataSet2"
        Me.ColegioBDDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ReportViewer1
        '
        Me.ReportViewer1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill
        ReportDataSource1.Name = "DataSet1"
        ReportDataSource1.Value = Me.DocenteBindingSource
        Me.ReportViewer1.LocalReport.DataSources.Add(ReportDataSource1)
        Me.ReportViewer1.LocalReport.ReportEmbeddedResource = "CapaPresentacion.Report2.rdlc"
        Me.ReportViewer1.Location = New System.Drawing.Point(0, 0)
        Me.ReportViewer1.Name = "ReportViewer1"
        Me.ReportViewer1.Size = New System.Drawing.Size(1197, 445)
        Me.ReportViewer1.TabIndex = 0
        '
        'DocenteTableAdapter
        '
        Me.DocenteTableAdapter.ClearBeforeFill = True
        '
        'ReporteDocente
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1197, 445)
        Me.Controls.Add(Me.ReportViewer1)
        Me.Name = "ReporteDocente"
        Me.Text = "ReporteApoderado"
        CType(Me.DocenteBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColegioBDDataSet2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ReportViewer1 As Microsoft.Reporting.WinForms.ReportViewer
    Friend WithEvents DocenteBindingSource As BindingSource
    Friend WithEvents ColegioBDDataSet2 As ColegioBDDataSet2
    Friend WithEvents DocenteTableAdapter As ColegioBDDataSet2TableAdapters.DocenteTableAdapter
End Class
