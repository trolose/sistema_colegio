﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmalumno
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim FnaPerLabel As System.Windows.Forms.Label
        Me.txtbuscar = New System.Windows.Forms.TextBox()
        Me.btnregistrar = New System.Windows.Forms.Button()
        Me.btnsalir = New System.Windows.Forms.Button()
        Me.btnnuevo = New System.Windows.Forms.Button()
        Me.txteda = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txttel = New System.Windows.Forms.TextBox()
        Me.txtema = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btneliminar = New System.Windows.Forms.Button()
        Me.datalistado = New System.Windows.Forms.DataGridView()
        Me.Eliminar = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.txtdir = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtama = New System.Windows.Forms.TextBox()
        Me.txtapa = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtnombre = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtdni = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.inexistente = New System.Windows.Forms.LinkLabel()
        Me.s = New System.Windows.Forms.GroupBox()
        Me.cbcampo = New System.Windows.Forms.ComboBox()
        Me.btnimprimir = New System.Windows.Forms.Button()
        Me.cbeliminar = New System.Windows.Forms.CheckBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.iniciar = New System.Windows.Forms.CheckBox()
        Me.cbxestado = New System.Windows.Forms.ComboBox()
        Me.txtestado = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.FnaPerDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.PersonaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ColegioBDDataSet = New CapaPresentacion.ColegioBDDataSet()
        Me.btneditar = New System.Windows.Forms.Button()
        Me.erroricon = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.PersonaTableAdapter = New CapaPresentacion.ColegioBDDataSetTableAdapters.PersonaTableAdapter()
        Me.TableAdapterManager = New CapaPresentacion.ColegioBDDataSetTableAdapters.TableAdapterManager()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label12 = New System.Windows.Forms.Label()
        FnaPerLabel = New System.Windows.Forms.Label()
        CType(Me.datalistado, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.s.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PersonaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColegioBDDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.erroricon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'FnaPerLabel
        '
        FnaPerLabel.AutoSize = True
        FnaPerLabel.Location = New System.Drawing.Point(34, 144)
        FnaPerLabel.Name = "FnaPerLabel"
        FnaPerLabel.Size = New System.Drawing.Size(118, 20)
        FnaPerLabel.TabIndex = 23
        FnaPerLabel.Text = "Fecha nacimiento "
        '
        'txtbuscar
        '
        Me.txtbuscar.Location = New System.Drawing.Point(193, 44)
        Me.txtbuscar.Name = "txtbuscar"
        Me.txtbuscar.Size = New System.Drawing.Size(293, 26)
        Me.txtbuscar.TabIndex = 2
        '
        'btnregistrar
        '
        Me.btnregistrar.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.btnregistrar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnregistrar.Enabled = False
        Me.btnregistrar.Location = New System.Drawing.Point(154, 323)
        Me.btnregistrar.Name = "btnregistrar"
        Me.btnregistrar.Size = New System.Drawing.Size(92, 31)
        Me.btnregistrar.TabIndex = 23
        Me.btnregistrar.Text = "Registrar"
        Me.btnregistrar.UseVisualStyleBackColor = False
        '
        'btnsalir
        '
        Me.btnsalir.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.btnsalir.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnsalir.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.btnsalir.ForeColor = System.Drawing.Color.Black
        Me.btnsalir.Location = New System.Drawing.Point(18, 28)
        Me.btnsalir.Name = "btnsalir"
        Me.btnsalir.Size = New System.Drawing.Size(78, 21)
        Me.btnsalir.TabIndex = 22
        Me.btnsalir.Text = "Regresar"
        Me.btnsalir.UseVisualStyleBackColor = False
        '
        'btnnuevo
        '
        Me.btnnuevo.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.btnnuevo.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnnuevo.Location = New System.Drawing.Point(347, 310)
        Me.btnnuevo.Name = "btnnuevo"
        Me.btnnuevo.Size = New System.Drawing.Size(85, 29)
        Me.btnnuevo.TabIndex = 20
        Me.btnnuevo.Text = "Nuevo"
        Me.btnnuevo.UseVisualStyleBackColor = False
        '
        'txteda
        '
        Me.txteda.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.txteda.Enabled = False
        Me.txteda.ForeColor = System.Drawing.SystemColors.InactiveCaption
        Me.txteda.Location = New System.Drawing.Point(220, 167)
        Me.txteda.MaxLength = 2
        Me.txteda.Name = "txteda"
        Me.txteda.Size = New System.Drawing.Size(52, 26)
        Me.txteda.TabIndex = 19
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(225, 260)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(42, 20)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "Email"
        '
        'txttel
        '
        Me.txttel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txttel.Enabled = False
        Me.txttel.ForeColor = System.Drawing.SystemColors.Desktop
        Me.txttel.Location = New System.Drawing.Point(220, 227)
        Me.txttel.MaxLength = 9
        Me.txttel.Name = "txttel"
        Me.txttel.Size = New System.Drawing.Size(165, 26)
        Me.txttel.TabIndex = 17
        '
        'txtema
        '
        Me.txtema.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtema.Enabled = False
        Me.txtema.ForeColor = System.Drawing.SystemColors.Desktop
        Me.txtema.Location = New System.Drawing.Point(220, 285)
        Me.txtema.Name = "txtema"
        Me.txtema.Size = New System.Drawing.Size(165, 26)
        Me.txtema.TabIndex = 15
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(46, 204)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(65, 20)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "Direccion"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(225, 204)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(61, 20)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Telefono"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(314, 144)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(41, 20)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Sexo"
        '
        'btneliminar
        '
        Me.btneliminar.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.btneliminar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btneliminar.Location = New System.Drawing.Point(438, 310)
        Me.btneliminar.Name = "btneliminar"
        Me.btneliminar.Size = New System.Drawing.Size(90, 31)
        Me.btneliminar.TabIndex = 4
        Me.btneliminar.Text = "Eliminar"
        Me.btneliminar.UseVisualStyleBackColor = False
        '
        'datalistado
        '
        Me.datalistado.AllowUserToAddRows = False
        Me.datalistado.AllowUserToDeleteRows = False
        Me.datalistado.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.datalistado.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Eliminar})
        Me.datalistado.Location = New System.Drawing.Point(30, 111)
        Me.datalistado.Name = "datalistado"
        Me.datalistado.ReadOnly = True
        Me.datalistado.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.datalistado.Size = New System.Drawing.Size(580, 193)
        Me.datalistado.TabIndex = 0
        '
        'Eliminar
        '
        Me.Eliminar.HeaderText = "Eliminar"
        Me.Eliminar.Name = "Eliminar"
        Me.Eliminar.ReadOnly = True
        '
        'txtdir
        '
        Me.txtdir.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtdir.Enabled = False
        Me.txtdir.ForeColor = System.Drawing.SystemColors.Desktop
        Me.txtdir.Location = New System.Drawing.Point(28, 227)
        Me.txtdir.Name = "txtdir"
        Me.txtdir.Size = New System.Drawing.Size(165, 26)
        Me.txtdir.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(231, 144)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(41, 20)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Edad"
        '
        'txtama
        '
        Me.txtama.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtama.Enabled = False
        Me.txtama.ForeColor = System.Drawing.SystemColors.Desktop
        Me.txtama.Location = New System.Drawing.Point(220, 113)
        Me.txtama.Name = "txtama"
        Me.txtama.Size = New System.Drawing.Size(165, 26)
        Me.txtama.TabIndex = 7
        '
        'txtapa
        '
        Me.txtapa.Enabled = False
        Me.txtapa.ForeColor = System.Drawing.SystemColors.Desktop
        Me.txtapa.Location = New System.Drawing.Point(28, 113)
        Me.txtapa.Name = "txtapa"
        Me.txtapa.Size = New System.Drawing.Size(165, 26)
        Me.txtapa.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label3.Location = New System.Drawing.Point(43, 90)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(109, 20)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Apellido Paterno"
        '
        'txtnombre
        '
        Me.txtnombre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtnombre.Enabled = False
        Me.txtnombre.ForeColor = System.Drawing.SystemColors.Desktop
        Me.txtnombre.Location = New System.Drawing.Point(220, 61)
        Me.txtnombre.Name = "txtnombre"
        Me.txtnombre.Size = New System.Drawing.Size(172, 26)
        Me.txtnombre.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Location = New System.Drawing.Point(225, 38)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(57, 20)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Nombre"
        '
        'txtdni
        '
        Me.txtdni.BackColor = System.Drawing.Color.White
        Me.txtdni.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtdni.Enabled = False
        Me.txtdni.ForeColor = System.Drawing.SystemColors.Desktop
        Me.txtdni.Location = New System.Drawing.Point(28, 61)
        Me.txtdni.MaxLength = 8
        Me.txtdni.Name = "txtdni"
        Me.txtdni.Size = New System.Drawing.Size(165, 26)
        Me.txtdni.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.Location = New System.Drawing.Point(24, 38)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Dni Alumno"
        '
        'inexistente
        '
        Me.inexistente.AutoSize = True
        Me.inexistente.Location = New System.Drawing.Point(380, 233)
        Me.inexistente.Name = "inexistente"
        Me.inexistente.Size = New System.Drawing.Size(118, 20)
        Me.inexistente.TabIndex = 3
        Me.inexistente.TabStop = True
        Me.inexistente.Text = "Datos inexistentes"
        '
        's
        '
        Me.s.BackColor = System.Drawing.Color.Transparent
        Me.s.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.s.Controls.Add(Me.cbcampo)
        Me.s.Controls.Add(Me.btnimprimir)
        Me.s.Controls.Add(Me.cbeliminar)
        Me.s.Controls.Add(Me.btneliminar)
        Me.s.Controls.Add(Me.inexistente)
        Me.s.Controls.Add(Me.txtbuscar)
        Me.s.Controls.Add(Me.datalistado)
        Me.s.Controls.Add(Me.btnnuevo)
        Me.s.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.s.Location = New System.Drawing.Point(18, 74)
        Me.s.Name = "s"
        Me.s.Size = New System.Drawing.Size(616, 354)
        Me.s.TabIndex = 3
        Me.s.TabStop = False
        Me.s.Text = "Listado de Alumnos"
        '
        'cbcampo
        '
        Me.cbcampo.AutoCompleteCustomSource.AddRange(New String() {"dniAlu"})
        Me.cbcampo.FormattingEnabled = True
        Me.cbcampo.Items.AddRange(New Object() {"Dni"})
        Me.cbcampo.Location = New System.Drawing.Point(32, 44)
        Me.cbcampo.Name = "cbcampo"
        Me.cbcampo.Size = New System.Drawing.Size(121, 28)
        Me.cbcampo.TabIndex = 7
        Me.cbcampo.Text = "Seleccione"
        '
        'btnimprimir
        '
        Me.btnimprimir.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.btnimprimir.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnimprimir.Location = New System.Drawing.Point(534, 310)
        Me.btnimprimir.Name = "btnimprimir"
        Me.btnimprimir.Size = New System.Drawing.Size(76, 31)
        Me.btnimprimir.TabIndex = 6
        Me.btnimprimir.Text = "Reporte"
        Me.btnimprimir.UseVisualStyleBackColor = False
        '
        'cbeliminar
        '
        Me.cbeliminar.AutoSize = True
        Me.cbeliminar.Location = New System.Drawing.Point(32, 84)
        Me.cbeliminar.Name = "cbeliminar"
        Me.cbeliminar.Size = New System.Drawing.Size(75, 24)
        Me.cbeliminar.TabIndex = 5
        Me.cbeliminar.Text = "Eliminar"
        Me.cbeliminar.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(225, 90)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(111, 20)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Apellido Materno"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GroupBox1.Controls.Add(Me.iniciar)
        Me.GroupBox1.Controls.Add(Me.cbxestado)
        Me.GroupBox1.Controls.Add(Me.txtestado)
        Me.GroupBox1.Controls.Add(Me.ComboBox1)
        Me.GroupBox1.Controls.Add(Me.FnaPerDateTimePicker)
        Me.GroupBox1.Controls.Add(Me.btnregistrar)
        Me.GroupBox1.Controls.Add(FnaPerLabel)
        Me.GroupBox1.Controls.Add(Me.btneditar)
        Me.GroupBox1.Controls.Add(Me.txteda)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.txttel)
        Me.GroupBox1.Controls.Add(Me.txtema)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.txtdir)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtama)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txtapa)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtnombre)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtdni)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(653, 74)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(439, 369)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Registro"
        '
        'iniciar
        '
        Me.iniciar.AutoSize = True
        Me.iniciar.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.iniciar.Location = New System.Drawing.Point(28, 323)
        Me.iniciar.Name = "iniciar"
        Me.iniciar.Size = New System.Drawing.Size(62, 24)
        Me.iniciar.TabIndex = 29
        Me.iniciar.Text = "Iniciar"
        Me.iniciar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.iniciar.UseVisualStyleBackColor = False
        '
        'cbxestado
        '
        Me.cbxestado.Enabled = False
        Me.cbxestado.FormattingEnabled = True
        Me.cbxestado.Items.AddRange(New Object() {"Habilitado", "Deshabilitado"})
        Me.cbxestado.Location = New System.Drawing.Point(28, 283)
        Me.cbxestado.Name = "cbxestado"
        Me.cbxestado.Size = New System.Drawing.Size(165, 28)
        Me.cbxestado.TabIndex = 28
        '
        'txtestado
        '
        Me.txtestado.AutoSize = True
        Me.txtestado.Location = New System.Drawing.Point(36, 260)
        Me.txtestado.Name = "txtestado"
        Me.txtestado.Size = New System.Drawing.Size(51, 20)
        Me.txtestado.TabIndex = 27
        Me.txtestado.Text = "Estado"
        '
        'ComboBox1
        '
        Me.ComboBox1.Enabled = False
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"M", "F"})
        Me.ComboBox1.Location = New System.Drawing.Point(318, 167)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(49, 28)
        Me.ComboBox1.TabIndex = 25
        '
        'FnaPerDateTimePicker
        '
        Me.FnaPerDateTimePicker.CustomFormat = "dd-MM-yyyy"
        Me.FnaPerDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.PersonaBindingSource, "fnaPer", True))
        Me.FnaPerDateTimePicker.Enabled = False
        Me.FnaPerDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.FnaPerDateTimePicker.Location = New System.Drawing.Point(28, 165)
        Me.FnaPerDateTimePicker.Name = "FnaPerDateTimePicker"
        Me.FnaPerDateTimePicker.Size = New System.Drawing.Size(168, 26)
        Me.FnaPerDateTimePicker.TabIndex = 24
        Me.FnaPerDateTimePicker.Value = New Date(2012, 1, 1, 17, 11, 0, 0)
        '
        'PersonaBindingSource
        '
        Me.PersonaBindingSource.DataMember = "Persona"
        Me.PersonaBindingSource.DataSource = Me.ColegioBDDataSet
        '
        'ColegioBDDataSet
        '
        Me.ColegioBDDataSet.DataSetName = "ColegioBDDataSet"
        Me.ColegioBDDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'btneditar
        '
        Me.btneditar.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.btneditar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btneditar.Location = New System.Drawing.Point(154, 323)
        Me.btneditar.Name = "btneditar"
        Me.btneditar.Size = New System.Drawing.Size(92, 31)
        Me.btneditar.TabIndex = 21
        Me.btneditar.Text = "Editar"
        Me.btneditar.UseVisualStyleBackColor = False
        '
        'erroricon
        '
        Me.erroricon.ContainerControl = Me
        '
        'PersonaTableAdapter
        '
        Me.PersonaTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AlumnoTableAdapter = Nothing
        Me.TableAdapterManager.Año_EscolarTableAdapter = Nothing
        Me.TableAdapterManager.ApoderadoTableAdapter = Nothing
        Me.TableAdapterManager.AulaTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CursoTableAdapter = Nothing
        Me.TableAdapterManager.DocenteTableAdapter = Nothing
        Me.TableAdapterManager.EspecialidadTableAdapter = Nothing
        Me.TableAdapterManager.HorarioTableAdapter = Nothing
        Me.TableAdapterManager.MatriculaTableAdapter = Nothing
        Me.TableAdapterManager.NotaTableAdapter = Nothing
        Me.TableAdapterManager.ParentescoTableAdapter = Nothing
        Me.TableAdapterManager.PersonaTableAdapter = Me.PersonaTableAdapter
        Me.TableAdapterManager.tipousuarioTableAdapter = Nothing
        Me.TableAdapterManager.TrimestreTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = CapaPresentacion.ColegioBDDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.usuarioTableAdapter = Nothing
        '
        'Timer1
        '
        Me.Timer1.Interval = 1
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Arial Narrow", 26.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Red
        Me.Label12.Location = New System.Drawing.Point(263, 7)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(366, 42)
        Me.Label12.TabIndex = 32
        Me.Label12.Text = "REGISTRO DE ALUMNOS"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmalumno
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = Global.CapaPresentacion.My.Resources.Resources.Degradado22
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(645, 443)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.s)
        Me.Controls.Add(Me.btnsalir)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmalumno"
        Me.Text = "frmpersona1"
        CType(Me.datalistado, System.ComponentModel.ISupportInitialize).EndInit()
        Me.s.ResumeLayout(False)
        Me.s.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PersonaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColegioBDDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.erroricon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtbuscar As TextBox
    Friend WithEvents btnregistrar As Button
    Friend WithEvents btnsalir As Button
    Friend WithEvents btnnuevo As Button
    Friend WithEvents txteda As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txttel As TextBox
    Friend WithEvents txtema As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents btneliminar As Button
    Friend WithEvents datalistado As DataGridView
    Friend WithEvents txtdir As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtama As TextBox
    Friend WithEvents txtapa As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtnombre As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents inexistente As LinkLabel
    Friend WithEvents s As GroupBox
    Friend WithEvents Label4 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btneditar As Button
    Friend WithEvents erroricon As ErrorProvider
    Friend WithEvents cbeliminar As CheckBox
    Friend WithEvents btnimprimir As Button
    Friend WithEvents PersonaBindingSource As BindingSource
    Friend WithEvents ColegioBDDataSet As ColegioBDDataSet
    Friend WithEvents PersonaTableAdapter As ColegioBDDataSetTableAdapters.PersonaTableAdapter
    Friend WithEvents TableAdapterManager As ColegioBDDataSetTableAdapters.TableAdapterManager
    Friend WithEvents Timer1 As Timer
    Friend WithEvents FnaPerDateTimePicker As DateTimePicker
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents txtestado As Label
    Friend WithEvents cbxestado As ComboBox
    Friend WithEvents cbcampo As ComboBox
    Public WithEvents txtdni As TextBox
    Friend WithEvents Eliminar As DataGridViewCheckBoxColumn
    Friend WithEvents Label12 As Label
    Friend WithEvents iniciar As CheckBox
End Class
