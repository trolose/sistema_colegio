﻿Imports System.Data.SqlClient
Imports System.Text.RegularExpressions
Imports CapaDatos
Imports CapaEntidad
Public Class frmapoderado
    Private dt As New DataTable
    Public Property CMD As Object

    Private Sub frmapoderado_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        mostrarapoderado()
    End Sub
    Public Sub limpiar()
        btnregistrar.Visible = True
        btneditar.Visible = False
        txtdni.Text = ""
        txtnombre.Text = ""
        txtapa.Text = ""
        txtama.Text = ""
        txtedad.Text = ""
        ComboBox1.Text = ""
        txttelefono.Text = ""
        txtdireccion.Text = ""
        FnaApoDateTimePicker1.Text = ""
        txtocu.Text = ""
        ComboBox2.Text = ""
        ComboBox3.Text = ""
    End Sub
    Public Sub limpiarduplicado()
        txtdni.Text = ""
        txttelefono.Text = ""
    End Sub

    Private Sub mostrarapoderado()
        Try
            Dim func As New fapoderado
            dt = func.mostrarapoderado
            datalistado.Columns.Item("Eliminar").Visible = False


            If dt.Rows.Count <> 0 Then
                datalistado.DataSource = dt
                txtbuscar.Enabled = True
                datalistado.ColumnHeadersVisible = True
                inexistente.Visible = False
            Else
                datalistado.DataSource = Nothing
                txtbuscar.Enabled = False
                datalistado.ColumnHeadersVisible = False
                inexistente.Visible = True
            End If



        Catch ex As Exception

            MsgBox(ex.Message)
        End Try
        btnnuevo.Visible = True
        btneditar.Visible = False

        buscardniapoderado()
    End Sub

    Private Sub buscardniapoderado()
        Try
            Dim ds As New DataSet
            ds.Tables.Add(dt.Copy)
            Dim dv As New DataView(ds.Tables(0))

            dv.RowFilter = String.Format("Convert (dniApo,'System.String')", cbocampo.Text) & " like '%" & txtbuscar.Text & "%'"



            If dv.Count <> 0 Then
                inexistente.Visible = False
                datalistado.DataSource = dv

            Else
                inexistente.Visible = True
                datalistado.DataSource = Nothing

            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        menuprincipal.Show()
        Me.Hide()
    End Sub

    Private Sub btnnuevo_Click(sender As Object, e As EventArgs) Handles btnnuevo.Click
        Me.Width = 1000
        limpiar()
        txtdni.Focus()
        mostrarapoderado()

        If txtdni.Enabled = True Then
        Else
            txtdni.Enabled = True
        End If
    End Sub

    Private Sub btnregistrar_Click(sender As Object, e As EventArgs) Handles btnregistrar.Click
        'dniapo = txtdni.Text'
        If Me.ValidateChildren = True And txtdni.Text <> "" And txtnombre.Text <> "" And txtapa.Text <> "" And txtama.Text <>
                     "" And txtedad.Text <> "" And ComboBox1.Text <> "" And txttelefono.Text <> "" And txtdireccion.Text <> "" And FnaApoDateTimePicker1.Text <> "" And txtocu.Text <> "" And ComboBox2.Text <> "" And ComboBox3.Text <> "" Then
            Try
                Dim dts As New vapoderado
                Dim func As New fapoderado

                dts.gdniApo = txtdni.Text
                dts.gnomApo = txtnombre.Text
                dts.gapaApo = txtapa.Text
                dts.gamaApo = txtama.Text
                dts.gedaApo = txtedad.Text
                dts.gsexApo = ComboBox1.Text
                dts.gtelApo = txttelefono.Text
                dts.gdirApo = txtdireccion.Text
                dts.gfnaApo = FnaApoDateTimePicker1.Text
                dts.gocuApo = txtocu.Text
                dts.geciApo = ComboBox2.Text
                dts.gginApo = ComboBox3.Text


                If func.insertarapoderado(dts) Then

                    MessageBox.Show("Registro de apoderado", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    MessageBox.Show("Seleccione su registro, para definir parentesco", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    mostrarapoderado()
                    limpiarduplicado()



                Else
                    MessageBox.Show("Apoderado no fue registrado intente de nuevo ", "Guardando registros", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    mostrarapoderado()
                    limpiarduplicado()

                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Else
            MessageBox.Show("Faltan ingresar datos ", "Guardando datos", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If


    End Sub

    Private Function MENSAJE() As String
        Throw New NotImplementedException()
    End Function

    Private Function dniapo() As String
        Throw New NotImplementedException()
    End Function

    Private Sub datalistado_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles datalistado.CellContentClick
        If e.ColumnIndex = Me.datalistado.Columns.Item("Eliminar").Index Then
            Dim chkcell As DataGridViewCheckBoxCell = Me.datalistado.Rows(e.RowIndex).Cells("Eliminar")
            chkcell.Value = Not chkcell.Value
        End If
    End Sub

    Private Sub btneliminar_Click(sender As Object, e As EventArgs) Handles btneliminar.Click
        Dim result As DialogResult
        result = MessageBox.Show("¿Realmente quiere eliminar a los apoderados seleccionados?", "Eliminando registros ", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
        If result = DialogResult.OK Then
            Try
                For Each row As DataGridViewRow In datalistado.Rows
                    Dim marcado As Boolean = Convert.ToBoolean(row.Cells("Eliminar").Value)
                    If marcado Then
                        Dim onekey As Integer = Convert.ToInt32(row.Cells("dniApo").Value)
                        Dim vdb As New vapoderado
                        Dim func As New fapoderado
                        vdb.gdniApo = onekey

                        If func.eliminarapoderado(vdb) Then
                        Else
                            MessageBox.Show("Apoderado no eliminado", "Eliminando registros ", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        End If
                    End If

                Next
                Call mostrarapoderado()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Else
            MessageBox.Show("Cancelando eliminacion de registros", "Eliminando registros ", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Call mostrarapoderado()
        End If
        Call limpiar()
    End Sub

    Private Sub datalistado_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles datalistado.CellClick
        Dim I As String = e.RowIndex
        frmparentesco.txtdniapo.Text = datalistado.Rows(I).Cells(1).Value

        txtdni.Text = datalistado.SelectedCells.Item(1).Value
        txtnombre.Text = datalistado.SelectedCells.Item(2).Value
        txtapa.Text = datalistado.SelectedCells.Item(3).Value
        txtama.Text = datalistado.SelectedCells.Item(4).Value
        txtedad.Text = datalistado.SelectedCells.Item(5).Value
        ComboBox1.Text = datalistado.SelectedCells.Item(6).Value
        txttelefono.Text = datalistado.SelectedCells.Item(7).Value
        txtdireccion.Text = datalistado.SelectedCells.Item(8).Value
        FnaApoDateTimePicker1.Text = datalistado.SelectedCells.Item(9).Value
        txtocu.Text = datalistado.SelectedCells.Item(10).Value
        ComboBox2.Text = datalistado.SelectedCells.Item(11).Value
        ComboBox3.Text = datalistado.SelectedCells.Item(12).Value
        btneditar.Visible = True
        btnregistrar.Visible = False

        If txtdni.Enabled = False Then
        Else
            txtdni.Enabled = False
        End If

    End Sub

    Private Sub btneditar_Click(sender As Object, e As EventArgs) Handles btneditar.Click
        Dim result As DialogResult
        result = MessageBox.Show("Realmente desea editar los datos del alumno", "Modificando registros ", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
        If result = DialogResult.OK Then

            If Me.ValidateChildren = True And txtdni.Text <> "" And txtnombre.Text <> "" And txtapa.Text <> "" And txtama.Text <>
                     "" And txtedad.Text <> "" And ComboBox1.Text <> "" And txttelefono.Text <> "" And txtdireccion.Text <> "" And FnaApoDateTimePicker1.Text <> "" And txtocu.Text <> "" And ComboBox2.Text <> "" And ComboBox3.Text <> "" Then
                Try
                    Dim dts As New vapoderado
                    Dim func As New fapoderado

                    If txtdni.Enabled = False Then

                    Else
                        txtdni.Enabled = True

                    End If

                    dts.gdniApo = txtdni.Text
                    dts.gnomApo = txtnombre.Text
                    dts.gapaApo = txtapa.Text
                    dts.gamaApo = txtama.Text
                    dts.gedaApo = txtedad.Text
                    dts.gsexApo = ComboBox1.Text
                    dts.gtelApo = txttelefono.Text
                    dts.gdirApo = txtdireccion.Text
                    dts.gfnaApo = FnaApoDateTimePicker1.Text
                    dts.gocuApo = txtocu.Text
                    dts.geciApo = ComboBox2.Text
                    dts.gginApo = ComboBox3.Text

                    If func.editarapoderado(dts) Then
                        MessageBox.Show("Apoderado modificado correctamente", "Modificando registros", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        mostrarapoderado()
                        limpiar()
                    Else
                        MessageBox.Show("Apoderado no fue modificado intente de nuevo ", "Modificando registros", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        mostrarapoderado()
                        limpiar()
                    End If
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try
            Else
                MessageBox.Show("Faltan ingresar datos ", "Guardando datos", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        End If

    End Sub

    Private Sub cbeliminar_CheckedChanged(sender As Object, e As EventArgs) Handles cbeliminar.CheckedChanged
        If cbeliminar.CheckState = CheckState.Checked Then
            datalistado.Columns.Item("Eliminar").Visible = True
        Else

            datalistado.Columns.Item("Eliminar").Visible = False
        End If

    End Sub

    Private Sub txtdni_TextChanged(sender As Object, e As EventArgs) Handles txtdni.TextChanged

    End Sub

    Private Sub txtdni_Validated(sender As Object, e As EventArgs) Handles txtdni.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Ingrese el dni de la persona por favor estos datos son obligatorios ")
        End If
        'solo acepte 8 digitos si es menos sale el mensaje
        If Len(txtdni.Text) < 8 Then
            btnregistrar.Visible = False
            MessageBox.Show("Faltan digitos al DNI", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            btnregistrar.Visible = True
        End If


    End Sub

    Private Sub txtnombre_TextChanged(sender As Object, e As EventArgs) Handles txtnombre.TextChanged

    End Sub

    Private Sub txtnombre_Validated(sender As Object, e As EventArgs) Handles txtnombre.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Ingrese direccion de la persona por favor estos datos son obligatorios ")
        End If
        If Len(txtnombre.Text) < 2 Then
            btnregistrar.Visible = False
            MessageBox.Show("Insertar mas  2 caracteres ", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            btnregistrar.Visible = True
        End If

    End Sub

    Private Sub txtapa_TextChanged(sender As Object, e As EventArgs) Handles txtapa.TextChanged

    End Sub

    Private Sub txtapa_Validated(sender As Object, e As EventArgs) Handles txtapa.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Ingrese direccion de la persona por favor estos datos son obligatorios ")
        End If
        If Len(txtapa.Text) < 2 Then
            btnregistrar.Visible = False
            MessageBox.Show("Insertar mas  2 caracteres ", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            btnregistrar.Visible = True
        End If

    End Sub

    Private Sub txtama_TextChanged(sender As Object, e As EventArgs) Handles txtama.TextChanged

    End Sub

    Private Sub txtama_Validated(sender As Object, e As EventArgs) Handles txtama.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Ingrese direccion de la persona por favor estos datos son obligatorios ")
        End If
        If Len(txtama.Text) < 2 Then
            btnregistrar.Visible = False
            MessageBox.Show("Insertar mas  2 caracteres ", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            btnregistrar.Visible = True
        End If

    End Sub

    Private Sub txtedad_TextChanged(sender As Object, e As EventArgs) Handles txtedad.TextChanged

    End Sub

    Private Sub txtedad_Validated(sender As Object, e As EventArgs) Handles txtedad.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Ingrese direccion de la persona por favor estos datos son obligatorios ")
        End If

    End Sub



    Private Sub txttelefono_TextChanged(sender As Object, e As EventArgs) Handles txttelefono.TextChanged

    End Sub

    Private Sub txttelefono_Validated(sender As Object, e As EventArgs) Handles txttelefono.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Ingrese direccion de la persona por favor estos datos son obligatorios ")
        End If
        If Len(txtdni.Text) < 8 Then
            btnregistrar.Visible = False
            MessageBox.Show("Faltan digitos", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            btnregistrar.Visible = True
        End If

    End Sub

    Private Sub txtdireccion_TextChanged(sender As Object, e As EventArgs) Handles txtdireccion.TextChanged

    End Sub

    Private Sub txtdireccion_Validated(sender As Object, e As EventArgs) Handles txtdireccion.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Ingrese direccion de la persona por favor estos datos son obligatorios ")
        End If
        If Len(txtdireccion.Text) < 2 Then
            btnregistrar.Visible = False
            MessageBox.Show("Insertar mas  2 caracteres ", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            btnregistrar.Visible = True
        End If

    End Sub

    Private Sub txtocu_TextChanged(sender As Object, e As EventArgs) Handles txtocu.TextChanged

    End Sub

    Private Sub txtocu_Validated(sender As Object, e As EventArgs) Handles txtocu.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Ingrese direccion de la persona por favor estos datos son obligatorios ")
        End If
        If Len(txtocu.Text) < 2 Then
            btnregistrar.Visible = False
            MessageBox.Show("Insertar mas  2 caracteres ", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            btnregistrar.Visible = True
        End If

    End Sub

    Private Sub txtdni_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtdni.KeyPress

        If (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If
    End Sub

    Private Sub txtnombre_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtnombre.KeyPress

        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub txtapa_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtapa.KeyPress

        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub txtama_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtama.KeyPress

        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub txttelefono_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txttelefono.KeyPress
        If (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If
    End Sub

    Private Sub txtocu_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtocu.KeyPress

        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo letras", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub txtedad_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtedad.KeyPress
        If (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If

    End Sub


    Private Sub txtbuscar_TextChanged(sender As Object, e As EventArgs) Handles txtbuscar.TextChanged
        buscardniapoderado()
    End Sub

    Private Sub FnaApoDateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles FnaApoDateTimePicker1.ValueChanged
        Dim FECHANAC As Date
        Dim EDAD As Integer
        FECHANAC = FnaApoDateTimePicker1.Value
        EDAD = Now.Year - FECHANAC.Year
        txtedad.Text = CStr(EDAD)
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        frmparentesco.ShowDialog()
    End Sub

    Private Sub iniciar_CheckedChanged(sender As Object, e As EventArgs) Handles iniciar.CheckedChanged
        If iniciar.Checked = True Then
            btnregistrar.Enabled = True

            txtdni.Enabled = True
            txtnombre.Enabled = True
            txtapa.Enabled = True
            txtama.Enabled = True
            FnaApoDateTimePicker1.Enabled = True
            txtapa.Enabled = True
            ComboBox1.Enabled = True
            txtdireccion.Enabled = True
            txttelefono.Enabled = True
            txtocu.Enabled = True
            ComboBox2.Enabled = True
            ComboBox3.Enabled = True

            txtdni.Focus()
        Else
            txtdni.Enabled = False
            txtnombre.Enabled = False
            txtapa.Enabled = False
            txtama.Enabled = False
            FnaApoDateTimePicker1.Enabled = False
            txtapa.Enabled = False
            ComboBox1.Enabled = False
            txtdireccion.Enabled = False
            txttelefono.Enabled = False
            txtocu.Enabled = False
            ComboBox2.Enabled = False
            ComboBox3.Enabled = False

            btnregistrar.Enabled = False
        End If
    End Sub

    Private Sub ComboBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ComboBox1.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        End If
    End Sub

    Private Sub ComboBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ComboBox2.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        End If
    End Sub

    Private Sub ComboBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ComboBox3.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        End If
    End Sub

    Private Sub btnimprimir_Click(sender As Object, e As EventArgs) Handles btnimprimir.Click
        RerporteApoderado.Show()
    End Sub

    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs) Handles GroupBox2.Enter

    End Sub
End Class