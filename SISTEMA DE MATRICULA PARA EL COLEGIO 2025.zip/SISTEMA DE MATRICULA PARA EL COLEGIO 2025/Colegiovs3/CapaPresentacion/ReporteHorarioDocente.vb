﻿Public Class ReporteHorarioDocente
    Private Sub ReporteHorarioDocente_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'uLTIMO.Horario' Puede moverla o quitarla según sea necesario.
        Me.HorarioTableAdapter.Fill(Me.uLTIMO.Horario)
        Me.ReportViewer1.RefreshReport()


    End Sub

    Private Sub ReportViewer1_Load(sender As Object, e As EventArgs) Handles ReportViewer1.Load

    End Sub
End Class