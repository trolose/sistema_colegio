﻿Imports System.Data.SqlClient
Imports System.Data
Imports CapaDatos
Imports CapaEntidad

Public Class frmHorario
    Private dt As New DataTable


    Private Sub frmHorario_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        mostrarhorario()
    End Sub
    Private Sub mostrarhorario()
        Try
            Dim func As New fhorario
            dt = func.mostrarhorario



            If dt.Rows.Count <> 0 Then
                datalistado.DataSource = dt
                txtbuscar.Enabled = True
                datalistado.ColumnHeadersVisible = True
                inexistente.Visible = False
            Else
                datalistado.DataSource = Nothing
                txtbuscar.Enabled = False
                datalistado.ColumnHeadersVisible = False
                inexistente.Visible = True
            End If



        Catch ex As Exception

            MsgBox(ex.Message)
        End Try
        btnsalir.Visible = True

        buscarhorario()
    End Sub

    Private Sub buscarhorario()
        Try
            Dim ds As New DataSet
            ds.Tables.Add(dt.Copy)
            Dim dv As New DataView(ds.Tables(0))

            dv.RowFilter = String.Format("Convert (dniDoc,'System.String')", cbcampo.Text) & " like '%" & txtbuscar.Text & "%'"

            If dv.Count <> 0 Then
                inexistente.Visible = False
                datalistado.DataSource = dv
                'ocultar_columnas()

            Else
                inexistente.Visible = True
                datalistado.DataSource = Nothing

            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    'Private Sub ocultar_columnas()
    ' datalistado.Columns(0).Visible = False
    ' End Sub




    Private Sub btnregistrar_Click(sender As Object, e As EventArgs) Handles btnregistrar.Click
        If Me.ValidateChildren = True And txthorario.Text <> "" And cbdia.Text <> "" And txtinicio.Text <> "" And txtfin.Text <>
                     "" And txtseccion.Text <> "" And cbaula.Text <> "" And txtdnidoc.Text <> "" And cbcurso.Text <> "" Then
            Try
                Dim dts As New vhorario
                Dim func As New fhorario
                dts.gcodHor = txthorario.Text
                dts.gdiaHor = cbdia.Text
                dts.ghinHor = txtinicio.Text
                dts.gHfiHor = txtfin.Text
                dts.gsecHor = txtseccion.Text
                dts.gcodAul = cbaula.Text
                dts.gdniDoc = txtdnidoc.Text
                dts.gcodCur = cbcurso.Text

                If func.insertarhorario(dts) Then
                    MessageBox.Show("Horario registrado correctamente", "Guardando registros", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    mostrarhorario()

                Else
                    MessageBox.Show("Horario no registrado, intente de nuevo ", "Guardando registros", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    mostrarhorario()


                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Else
            MessageBox.Show("Faltan ingresar datos ", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If

    End Sub



    Private Sub cbaula_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbaula.SelectedIndexChanged
        If cbaula.SelectedIndex = 0 Then
            txtseccion.Text = ""
        Else
            txtseccion.Text = "A"
        End If
    End Sub





    Private Sub btnsalir_Click(sender As Object, e As EventArgs) Handles btnsalir.Click
        menuprincipal.Show()
        Me.Hide()

    End Sub

    Private Sub inicio_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles inicio.CheckedChanged
        If inicio.Checked = True Then
            txtdnidoc.Enabled = True
            cbcurso.Enabled = True
            cbdia.Enabled = True
            btnregistrar.Enabled = True
            cbaula.Enabled = True
            txtinicio.Enabled = True
            txtfin.Enabled = True
            txtdnidoc.Focus()
        Else

            txtdnidoc.Enabled = False
            cbcurso.Enabled = False
            cbdia.Enabled = False
            btnregistrar.Enabled = False
            cbaula.Enabled = False
            txtinicio.Enabled = False
            txtfin.Enabled = False
        End If
    End Sub

    Private Sub txtdnidoc_TextChanged(sender As Object, e As EventArgs) Handles txtdnidoc.TextChanged

    End Sub

    Private Sub txtdnidoc_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtdnidoc.KeyPress
        If (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
            MessageBox.Show("Por favor digite solo numeros", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End If
    End Sub

    Private Sub txtbuscar_TextChanged(sender As Object, e As EventArgs) Handles txtbuscar.TextChanged
        buscarhorario()
    End Sub

    Private Sub txtdnidoc_Validated(sender As Object, e As EventArgs) Handles txtdnidoc.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
    End Sub

    Private Sub cbdia_Validated(sender As Object, e As EventArgs) Handles cbdia.Validated
        If DirectCast(sender, ComboBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
    End Sub

    Private Sub txtinicio_Validated(sender As Object, e As EventArgs) Handles txtinicio.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
    End Sub

    Private Sub txtfin_Validated(sender As Object, e As EventArgs) Handles txtfin.Validated
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
    End Sub

    Private Sub cbaula_Validated(sender As Object, e As EventArgs) Handles cbaula.Validated
        If DirectCast(sender, ComboBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
    End Sub

    Private Sub cbcurso_Validated(sender As Object, e As EventArgs) Handles cbcurso.Validated
        If DirectCast(sender, ComboBox).Text.Length > 0 Then
            Me.erroricon.SetError(sender, "")
        Else
            Me.erroricon.SetError(sender, "Datos obligatorios ")
        End If
    End Sub

    Private Sub btnnuevo_Click(sender As Object, e As EventArgs) Handles btnnuevo.Click
        limpiar()
        txtdnidoc.Focus()
        mostrarhorario()
    End Sub
    Public Sub limpiar()
        btnregistrar.Visible = True
        txtdnidoc.Text = ""
        txtinicio.Text = ""
        txtfin.Text = ""
        cbdia.Text = ""
        cbaula.Text = ""
        cbcurso.Text = ""

    End Sub

    Private Sub cbcurso_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cbcurso.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True

        End If

    End Sub

    Private Sub editar_Click(sender As Object, e As EventArgs) Handles editar.Click
        Dim result As DialogResult
        result = MessageBox.Show("Realmente desea editar estos datos", "Modificando registros ", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
        If result = DialogResult.OK Then

            If Me.ValidateChildren = True And txthorario.Text <> "" And txtdnidoc.Text <> "" And cbdia.Text <> "" And txtinicio.Text <> "" And txtfin.Text <>
                     "" And txtseccion.Text <> "" And cbaula.Text <> "" And cbcurso.Text <> "" Then
                Try
                    Dim dts As New vhorario
                    Dim func As New fhorario
                    If txtdnidoc.Enabled = False Then

                    Else
                        txtdnidoc.Enabled = True

                    End If
                    dts.gcodHor = txthorario.Text
                    dts.gdniDoc = txtdnidoc.Text
                    dts.gdiaHor = cbdia.Text
                    dts.ghinHor = txtinicio.Text
                    dts.gHfiHor = txtfin.Text
                    dts.gsecHor = txtseccion.Text
                    dts.gcodAul = cbaula.Text
                    dts.gcodCur = cbcurso.Text



                    If func.editarhorario(dts) Then
                        MessageBox.Show("Horario modificado correctamente", "Modificando registros", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        mostrarhorario()
                        limpiar()
                    Else
                        MessageBox.Show("Horario no modificado intente de nuevo ", "Modificando registros", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        mostrarhorario()
                        limpiar()

                    End If
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try
            Else
                MessageBox.Show("Faltan ingresar datos ", "Guardando datos", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        End If

    End Sub

    Private Sub eliminar_Click(sender As Object, e As EventArgs) Handles btneliminar.Click
        Dim result As DialogResult
        result = MessageBox.Show("¿Realmente quiere eliminar a los alumnos seleccionados?", "Eliminando registros ", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
        If result = DialogResult.OK Then
            Try
                For Each row As DataGridViewRow In datalistado.Rows
                    Dim marcado As Boolean = Convert.ToBoolean(row.Cells("Eliminar").Value)
                    If marcado Then
                        Dim onekey As Integer = Convert.ToInt32(row.Cells("dniDoc").Value)
                        Dim vdb As New vhorario
                        Dim func As New fhorario
                        vdb.gcodHor = onekey

                        If func.eliminarhorario(vdb) Then
                        Else
                            MessageBox.Show("Horario no eliminado", "Eliminando registros ", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        End If
                    End If

                Next
                Call mostrarhorario()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Else
            MessageBox.Show("Cancelando eliminacion de registros", "Eliminando registros ", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Call mostrarhorario()
        End If
        Call limpiar()
    End Sub

    Private Sub cbeliminar_CheckedChanged(sender As Object, e As EventArgs) Handles cbeliminar.CheckedChanged
        If cbeliminar.CheckState = CheckState.Checked Then
            datalistado.Columns.Item("Eliminar").Visible = True
        Else

            datalistado.Columns.Item("Eliminar").Visible = False
        End If
    End Sub
    Private Sub datalistado_CellContentClick_1(sender As Object, e As DataGridViewCellEventArgs) Handles datalistado.CellContentClick
        If e.ColumnIndex = Me.datalistado.Columns.Item("Eliminar").Index Then
            Dim chkcell As DataGridViewCheckBoxCell = Me.datalistado.Rows(e.RowIndex).Cells("Eliminar")
            chkcell.Value = Not chkcell.Value
        End If
    End Sub

    Private Sub datalistado_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles datalistado.CellClick

        txthorario.Text = datalistado.SelectedCells.Item(1).Value
        cbdia.Text = datalistado.SelectedCells.Item(2).Value
        txtinicio.Text = datalistado.SelectedCells.Item(3).Value
        txtfin.Text = datalistado.SelectedCells.Item(4).Value
        txtseccion.Text = datalistado.SelectedCells.Item(5).Value
        cbaula.Text = datalistado.SelectedCells.Item(6).Value
        txtdnidoc.Text = datalistado.SelectedCells.Item(7).Value
        cbcurso.Text = datalistado.SelectedCells.Item(8).Value

        editar.Visible = True
        btnregistrar.Visible = False

    End Sub

    Private Sub cbaula_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cbaula.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        End If
    End Sub

    Private Sub cbdia_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cbdia.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True

        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        End If
    End Sub

    Private Sub btnimprimir_Click(sender As Object, e As EventArgs) Handles btnimprimir.Click
        ReporteHorarioDocente.Show()
    End Sub
End Class