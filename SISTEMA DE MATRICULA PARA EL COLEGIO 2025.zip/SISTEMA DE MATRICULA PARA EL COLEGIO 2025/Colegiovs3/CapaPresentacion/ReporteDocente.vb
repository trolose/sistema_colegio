﻿Public Class ReporteDocente
    Private Sub ReporteApoderado_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'ColegioBDDataSet2.Docente' Puede moverla o quitarla según sea necesario.
        Me.DocenteTableAdapter.Fill(Me.ColegioBDDataSet2.Docente)

        Me.ReportViewer1.RefreshReport()
    End Sub

    Private Sub ReportViewer1_Load(sender As Object, e As EventArgs) Handles ReportViewer1.Load

    End Sub
End Class