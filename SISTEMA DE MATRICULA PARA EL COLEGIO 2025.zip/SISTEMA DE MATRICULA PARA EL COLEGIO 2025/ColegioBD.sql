create database ColegioBD
go
use ColegioBD
go
create table Alumno 
(
dniAlu int check (dniAlu >=1000000 and dniAlu<=99999999)primary key,
nomAlu varchar(30) not null,
apaAlu varchar(30) not null,
amaAlu varchar(30) not null,
edaAlu int not null,
sexAlu char(1) not null Check(sexAlu IN('M','F')),
telAlu int  unique,
dirAlu varchar(50) not null,
fnaAlu date not null,
emaAlu varchar(30),
estado varchar(30)
)
go

create table Apoderado
(
dniApo int check (dniApo >=1000000 and dniApo<=99999999)primary key,
nomApo varchar(30) not null,
apaApo varchar(30) not null,
amaApo varchar(30) not null,
edaApo int not null,
sexApo char(1) not null Check(sexApo IN('M','F')),
telApo int null unique,
dirApo varchar(50) not null,
fnaApo date not null,
ocuApo varchar(50) not null,
eciApo char(30) not null,
ginApo varchar(20) not null
)
go


create table Parentesco
(
codPar  int identity (1,1)primary key,
parPar varchar(30) not null,
dniAlu int foreign key references Alumno,
dniApo int foreign key references Apoderado
)
go

select * from Parentesco

create table Aula
(
codAul int primary key,
capAul int not null,
vliAul int not null
)
delete aula where codAul ='7'
select * from Aula
go
create table A�o_Escolar
(
numAes char(4) primary key,
finiAes date not null,
fteAes date not null
)

create table Matricula
(
codMat int primary key,
fecMat date NOT NULL,
monMat decimal(10,2) not null,
graMat int CHECK(graMat between 1 AND 6) not null,
secMat char(1) not null CHECK(secMat IN('A','B')),
codAul int foreign key references Aula,
dniAlu int foreign key references Alumno,
numAes char(4) foreign key references A�o_Escolar
)
go
create table Curso
(
codCur varchar(30) primary key,
nomCur varchar(45) not null
)
go


create table Docente
(
dniDoc int check (dniDoc >=1000000 and dniDoc<=99999999)primary key,
nomDoc varchar(30) not null,
apaDoc varchar(30) not null,
amaDoc varchar(30) not null,
edaDoc int not null,
sexDoc char(1) not null Check(sexDoc IN('M','F')),
telDoc int  null unique,
dirDoc varchar(50) not null,
fnaDoc date not null,
emaDoc varchar(30),
espDoc varchar(30)
)
select * from Docente 
go

 
create table Horario
(
codHor int primary key,
diaHor varchar(12) not null,
hinHor time not null,
HfiHor time not null,
secHor char(1) not null,
codAul int not null,
dniDoc int foreign key references Docente,
codCur varchar(30) foreign key references Curso
)
go
create table usuario
(
codusuario varchar(3),
codtipo int,
usuario varchar(14),
pass varchar(12)
)
go
 create table tipousuario
 (
 codtipo int primary key,
 tiporol varchar(15)
 )
 go
 drop table usuario
 CREATE PROCEDURE Acceder
 @Id varchar(15),
 @Contrase�a varchar(15),
 @Tipo int
 as
 select * from Usuario
 where usuario = @id and pass = @contrase�a and codtipo = @tipo  


Insert Into usuario values('12','1','Anthony','123')
Insert Into usuario values('13','2', 'Ericka', '456')

select * from tipousuario

 use ColegioBD 

Insert Into tipousuario values(1,'administrador')
Insert Into tipousuario values(2,'secretaria')



INSERT INTO CURSO VALUES('MAT01','Matem�tica')
INSERT INTO CURSO VALUES('CTA01','Ciencia Tecnolog�a Y Ambiente')
INSERT INTO CURSO VALUES('COM01','Comunicaci�n')
INSERT INTO CURSO VALUES('PFR01','Persona Familia y Relaciones Humanas')
INSERT INTO CURSO VALUES('EF001','Educaci�n Fis�ca')
INSERT INTO CURSO VALUES('EA001','Educaci�n por Arte')
INSERT INTO CURSO VALUES('ET001','Educaci�n por Trabajo')
INSERT INTO CURSO VALUES('R0001','Religi�n')
INSERT INTO CURSO VALUES('I0001','Ingles')
select * from curso

insert into A�o_Escolar values (,)

--PROCEDIMIENTOS ALMACENADOS

CREATE PROCEDURE MATRICULADELETE
(
	@codMat int 
)
as
delete from Matricula
where codMat = @codMat
return 
go
CREATE PROC MATRICULAINSERT
(
	@codMat int,
	@fecMat date,
	@monMat decimal(10,2),
	@graMat int,
	@secMat char(1),
	@codAul int,
	@dniAlu int,
	@numAes char(4)
)
AS
INSERT MATRICULA (codMat,fecMat,monMat,graMat,secMat,codAul,dniAlu,numAes) VALUES(@codMat,@fecMat,@monMat,@graMat,@secMat,@codAul,@dniAlu,@numAes)
RETURN 
go

CREATE PROC MATRICULAUPDATE
(
@codMat int,
@fecMat date,
@monMat decimal(10,2),
@graMat int,
@secMat char(1),
@codAul int,
@dniAlu int,
@numAes char
)
AS
UPDATE Matricula SET 
codMat = @codMat,
fecMat = @fecMat,
monMat = @monMat,
graMat = @graMat,
secMat = @secMat,
codAul = @codAul,
dniAlu = @dniAlu,
numAes = @numAes

where codMat = @codMat
return
go

CREATE PROC MATRICULASELECT 
	AS
	SELECT * FROM Matricula 
go

CREATE PROC MATRICULAMAX
	AS
		SELECT MAX (codMat) FROM Matricula
go

CREATE PROC MATRICULAMIN
	AS
		SELECT MIN (codMat) FROM Matricula
----------------------------------------------------------------

CREATE PROC ALUMNODELETE
(
	@dniAlu char(8)
)
as
delete from Alumno
WHERE dniAlu = @dniAlu
return 
go
----------------------------------------------------------------------

create proc INSERTHORARIO
(
	@codHor int ,
	@diaHor varchar (12),
	@hinHor time ,
	@HfiHor time,
	@secHor char(1),
	@codAul int ,
	@dniDoc int ,
	@codCur varchar(30)
)
as 
insert into Horario (codHor,diaHor ,hinHor ,HfiHor ,secHor,codAul,dniDoc,codCur ) values (@codHor,@diaHor ,@hinHor ,@HfiHor ,@secHor,@codAul,@dniDoc,@codCur )

create procedure UPDATEHORARIO
(
	@codHor int ,
	@diaHor varchar (12),
	@hinHor time ,
	@HfiHor time,
	@secHor char(1),
	@codAul int ,
	@dniDoc int,
	@codCur varchar(30)

) 
AS 
	UPDATE HORARIO set
	codHor = @codHor,
	diaHor=@diaHor ,
	hinHor =@hinHor,
	HfiHor =@HfiHor ,
	secHor =@secHor ,
	codAul =@codAul ,
	dniDoc =@dniDoc ,
	codCur =@codCur 
where codHor = @codHor
return 
go

create proc SELECTHORARIO
 AS 
	SELECT * FROM Horario 

	CREATE PROC BUSCAR_HORARIO
		@dniDoc CHAR(8)
		AS BEGIN
		SELECT * FROM Horario   WHERE dniDoc  LIKE @dniDoc+'%'
		END


		
CREATE PROC HORARIODELETE
(
	@dniDoc int 
)
as
delete from Horario
WHERE dniDoc  = @dniDoc 
return 
go


----------------------------------------------------------------------
CREATE PROC ALUMNOINSERT
(
	@dniAlu int,
	@nomAlu varchar(30),
	@apaAlu varchar(30),
	@amaAlu varchar(30),
	@edaAlu int,
	@sexAlu char(1),
	@telAlu int,
	@dirAlu varchar(50),
	@fnaAlu date,
	@emaAlu varchar(30),
	@estado varchar(30)
)
	AS 
	INSERT INTO Alumno (dniAlu,nomAlu,apaAlu,amaAlu,edaAlu,sexAlu,telAlu,dirAlu,fnaAlu,emaAlu,estado) 
	values (@dniAlu,@nomAlu,@apaAlu,@amaAlu,@edaAlu,@sexAlu,@telAlu,@dirAlu,@fnaAlu,@emaAlu,@estado)
	return
go

CREATE PROC ALUMNOUPDATE
(
	@dniAlu INT,
	@nomAlu varchar(30),
	@apaAlu varchar(30),
	@amaAlu varchar(30),
	@edaAlu int,
	@sexAlu char(1),
	@telAlu int,
	@dirAlu varchar(50),
	@fnaAlu date,
	@emaAlu varchar(30),
	@estado varchar(30)
)
AS 
UPDATE Alumno set

	dniAlu = @dniAlu, 
	nomAlu = @nomAlu, 
	apaAlu = @apaAlu,
	amaAlu = @amaAlu,
	edaAlu = @edaAlu,
	sexAlu = @sexAlu,
	telAlu = @telAlu,
	dirAlu = @dirAlu,
	fnaAlu = @fnaAlu,
	emaAlu = @emaAlu, 
	estado = @estado 
	WHERE dniAlu = @dniAlu
	return 
	select * from Alumno
go
drop PROC BUSCAR_DNI_ALUMNO
		CREATE PROC BUSCAR_DNI_ALUMNO
		@dniAlu int
		AS BEGIN
		SELECT * FROM Alumno  WHERE dniAlu  LIKE @dniAlu+'%'
		END
		GO
		drop procedure BUSCAR_DNI_ALUMNO


CREATE PROC AlumnoSELECT 
	AS
	SELECT * FROM Alumno
go
CREATE PROC ALUMNOMIN
	AS
		SELECT MIN (dniAlu) FROM Alumno
go
SELECT * FROM [dbo].[A�o_Escolar]
CREATE PROC ALUMNOMAX
	AS
		SELECT MAX (dniAlu) FROM Alumno
-------------------------------------------------------------
CREATE PROC APODERADODELETE
(
	@dniApo char(8)
)
as 
delete from Apoderado 
where @dniApo = dniApo
return
go

CREATE PROC APODERADOINSERT
(
	@dniApo int,
	@nomApo varchar(30),
	@apaApo varchar(30),
	@amaApo varchar(30),
	@edaApo int,
	@sexApo char(1),
	@telApo int,
	@dirApo varchar(50),
	@fnaApo date,
	@ocuApo varchar(50),
	@eciApo char(30),
	@ginApo varchar(20)
)
AS 

INSERT INTO Apoderado (dniApo,nomApo,apaApo,amaApo,edaApo,sexApo,telApo,dirApo,fnaApo,ocuApo,eciApo,ginApo) values (@dniApo,@nomApo,@apaApo,@amaApo,@edaApo,@sexApo,@telApo,@dirApo,@fnaApo,@ocuApo,@eciApo,@ginApo)
----order by dniApo 
CREATE PROC APODERADOUPDATE
(
	@dniApo int,
	@nomApo varchar(30),
	@apaApo varchar(30),
	@amaApo varchar(30),
	@edaApo int,
	@sexApo char(1),
	@telApo int,
	@dirApo varchar(50),
	@fnaApo date,
	@ocuApo varchar(50),
	@eciApo char(30),
	@ginApo varchar(20)
)
AS
UPDATE Apoderado set 
	dniApo = @dniApo,
	nomApo = @nomApo,
	apaApo = @apaApo,
	amaApo = @amaApo,
	edaApo = @edaApo,
	sexApo = @sexApo,
	telApo = @telApo,
	dirApo = @dirApo,
	fnaApo = @fnaApo,
	ocuApo = @ocuApo,
	eciApo = @eciApo,
	ginApo = @ginApo
	WHERE dniApo = @dniApo
return
go

CREATE PROC BUSCARDNIAPODERADO
(@dniApo int
)
AS 
BEGIN
SELECT * FROM Apoderado WHERE dniApo  LIKE @dniApo+'%' 
END
GO


CREATE PROC APODERADOSELECT 
AS 
SELECT * FROM Apoderado
go

CREATE PROC APODERADOMIN
AS
SELECT MIN (dniApo) FROM Apoderado
go

CREATE PROC APODERADOMAX
AS
SELECT MAX (dniApo) FROM Apoderado

--------------------------------------------------

CREATE PROC PARENTESCODELETE
(
	@codPar int 
)
AS
DELETE Parentesco 
WHERE codPar = @codPar
RETURN 
delete Parentesco where codPar = 1


 ----------------- 
 drop proc PARENTESCODELETE
Create PROC PARENTESCOINSERT
(
@parPar varchar(30),
@dniAlu CHAR(8),
@dniApo CHAR(8)
)
AS
INSERT INTO Parentesco (parPar,dniAlu,dniApo) values(@parPar,@dniAlu,@dniApo)
return
go 


CREATE PROC PARENTESCOSELECT 
AS
SELECT * FROM Parentesco
go
CREATE PROC PARENTESCOMIN
AS
SELECT MIN (codPar) FROM Parentesco
go

CREATE PROC PARENTESCOMAX
AS
SELECT MAX (codPar) FROM Parentesco
-------------------------------------------------------------
CREATE PROC AULADELETE
(
	@codAul int
)
AS
DELETE FROM Aula 
WHERE codAul = @codAul
return

go

CREATE PROC AULAINSERT 
(
	@codAul int,
	@capAul int,
	@vliAul int
)
	AS
	INSERT INTO Aula (codAul,capAul,vliAul) VALUES (@codAul,@capAul,@vliAul)
	RETURN

	go

CREATE PROC AULAUPDATE 
(
	@codAul int,
	@capAul int,
	@vliAul int
)
	AS

	UPDATE Aula SET 
	codAul = @codAul,
	capAul = @capAul,
	vliAul = @vliAul

	WHERE codAul = @codAul
	return
go

CREATE PROC AULASELECT 
AS
SELECT * FROM Aula

go

CREATE PROC AULAMIN
AS
SELECT MIN (codAul) FROM Aula

go

CREATE PROC AULAMAX
AS
SELECT MAX (codAul) FROM Aula
----------------------------------------

CREATE PROC A�ODELETE
(
	@numAes char (4)
)
as
DELETE FROM A�o_Escolar
WHERE numAes = @numAes
return

go

CREATE PROC A�OINSERT 
(
	@numAes char(4),
	@finiAes date ,
	@fteAes date
)
	AS
	INSERT INTO A�o_Escolar (numAes,finiAes,fteAes) VALUES (@numAes,@finiAes,@fteAes)
	return

go

CREATE PROC A�OUPDATE
(
	@numAes char(4),
	@finiAes date ,
	@fteAes date
)
	AS
	UPDATE A�o_Escolar SET 
	numAes=@numAes,
	finiAes=@finiAes,
	fteAes= @fteAes 

	WHERE numAes = @numAes
	return

go
select * from A�o_Escolar
CREATE PROC A�OSELECT 
 AS 
	SELECT * FROM A�o_Escolar

go

CREATE PROC A�OMIN
	AS
		SELECT MIN (numAes) FROM A�o_Escolar

go

CREATE PROC A�OMAX
	AS
		SELECT MAX (numAes) FROM A�o_Escolar
-----------------------------------------------------
CREATE PROCEDURE DOCENTEDELETE
(
	@dniDoc int
)
as
delete from Docente
WHERE dniDoc = @dniDoc
return 
go

drop proc DOCENTEINSERT
CREATE PROC DOCENTEINSERT
(
	@dniDoc int ,
	@nomDoc varchar(30),
	@apaDoc varchar(30),
	@amaDoc varchar(30),
	@edaDoc int,
	@sexDoc char(1),
	@telDoc int,
	@dirDoc varchar(50),
	@fnaDoc date,
	@emaDoc varchar(30),
	@espDoc varchar(30)
	
)
	AS 
	INSERT INTO DOCENTE(dniDoc,nomDoc,apaDoc,amaDoc,edaDoc,sexDoc,telDoc,dirDoc,fnaDoc,emaDoc,espDoc) 
	values (@dniDoc,@nomDoc,@apaDoc,@amaDoc,@edaDoc,@sexDoc,@telDoc,@dirDoc,@fnaDoc,@emaDoc,@espDoc)
	return
go

CREATE PROC DOCENTEUPDATE 
(
	@dniDoc int,
	@nomDoc varchar(30),
	@apaDoc varchar(30),
	@amaDoc varchar(30),
	@edaDoc int,
	@sexDoc char(1),
	@telDoc int,
	@dirDoc varchar(50),
	@fnaDoc date,
	@emaDoc varchar(30),
	@espDoc varchar(30)
)
	AS

	UPDATE Docente SET 
	dniDoc = @dniDoc,
	nomDoc = @nomDoc,
	apaDoc = @amaDoc,
	amaDoc = @apaDoc,
	edaDoc = @edaDoc,
	sexDoc = @sexDoc,
	telDoc = @telDoc,
	dirDoc = @dirDoc,
	fnaDoc = @fnaDoc,
	emaDoc = @emaDoc,
	espDoc = @espDoc

	WHERE dniDoc = @dniDoc
	return

go
CREATE PROC BUSCAR_DOCENTE
		@dniDoc int
		AS BEGIN
		SELECT * FROM Docente  WHERE dniDoc  LIKE @dniDoc+'%'
		END
		GO
		drop procedure BUSCAR_DOCENTE

	CREATE PROC DOCENTESELECT 
 AS 
	SELECT * FROM Docente
go
CREATE PROC DOCENTEMIN
	AS
		SELECT MIN (dniDoc) FROM Docente
go
		
CREATE PROC DOCENTEMAX
	AS
		SELECT MAX (dniDoc) FROM Docente

----------------------------------------------------------------------------------------
		

 
	
